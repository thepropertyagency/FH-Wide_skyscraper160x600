(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.IMG01jpgcopy = function() {
	this.initialize(img.IMG01jpgcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,556);


(lib.IMG02jpgcopy = function() {
	this.initialize(img.IMG02jpgcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,556);


(lib.IMG03 = function() {
	this.initialize(img.IMG03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,480,300);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG03();
	this.instance.parent = this;
	this.instance.setTransform(-179,-111.85,0.7458,0.7458);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-179,-111.8,358,223.7);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG03();
	this.instance.parent = this;
	this.instance.setTransform(-179,-111.85,0.7458,0.7458);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-179,-111.8,358,223.7);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG02jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG02jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG01jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG01jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgbA0IAAhnIAOAAIAABZIApAAIAAAOg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol13, new cjs.Rectangle(-2.8,-5.1,5.6,10.3), null);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgbA0IAAhnIAOAAIAABZIApAAIAAAOg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12, new cjs.Rectangle(-2.8,-5.1,5.6,10.3), null);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgGA0IAAhnIANAAIAABng");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11, new cjs.Rectangle(-0.7,-5.1,1.4,10.3), null);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AAZA0IAAgtIgxAAIAAAtIgOAAIAAhnIAOAAIAAAuIAxAAIAAguIAOAAIAABng");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(-3.9,-5.1,7.8,10.3), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgdA0IAAhnIA7AAIAAAOIgtAAIAAAgIAkAAIAAANIgkAAIAAAsg");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(-3,-5.1,6,10.3), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgGA0IAAhnIANAAIAABng");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-0.7,-5.1,1.4,10.3), null);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgfA0IAAhnIA9AAIAAAOIguAAIAAAgIAoAAIAAANIgoAAIAAAeIAvAAIAAAOg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(-3.1,-5.1,6.300000000000001,10.3), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgeA0IAAhnIA8AAIAAAOIguAAIAAAgIAoAAIAAANIgoAAIAAAeIAvAAIAAAOg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-3.1,-5.1,6.300000000000001,10.3), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgGA0IAAhZIgfAAIAAgOIBLAAIAAAOIgfAAIAABZg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(-3.8,-5.1,7.699999999999999,10.3), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgOBJIAAiQIAdAAIAACQg");
	this.shape.setTransform(49.225,22.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2E2E2E").s().p("AgOBJIAAiQIAdAAIAACQg");
	this.shape_1.setTransform(43.525,22.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2E2E2E").s().p("AgOBKIAAhjIAdAAIAABjgAgMgqQgFgGAAgHQAAgHAFgGQAFgFAHAAQAHAAAFAFQAGAGAAAHQAAAHgGAGQgFAFgHAAQgHAAgFgFg");
	this.shape_2.setTransform(37.825,22.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2E2E2E").s().p("AAcBHIAAg5Ig4AAIAAA5IgfAAIAAiNIAfAAIAAA4IA4AAIAAg4IAgAAIAACNg");
	this.shape_3.setTransform(27.45,22.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2E2E2E").s().p("AghAnQgQgPAAgYQAAgWAQgPQAOgPATAAQAXAAAOAOQANANAAAYIgBAJIhEAAQAAAIAHAGQAHAFAIAAQAPAAAFgNIAZAHQgEAOgLAIQgNAKgSAAQgUAAgPgOgAAUgLQAAgHgEgEQgGgGgKAAQgHAAgGAGQgFAFAAAGIAmAAIAAAAg");
	this.shape_4.setTransform(9.425,24.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2E2E2E").s().p("AghAnQgQgPAAgYQAAgWAQgPQAOgPATAAQAXAAAOAOQANANAAAYIgBAJIhEAAQAAAIAHAGQAHAFAIAAQAPAAAFgNIAZAHQgEAOgLAIQgNAKgSAAQgUAAgPgOgAAUgLQAAgHgEgEQgGgGgKAAQgHAAgGAGQgFAFAAAGIAmAAIAAAAg");
	this.shape_5.setTransform(-1.725,24.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2E2E2E").s().p("AgfAyIAAhiIAeAAIAAANQAGgOATAAIAHABIAAAeIgJgBQgKAAgGAGQgGAHAAANIAAArg");
	this.shape_6.setTransform(-10.85,24.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2E2E2E").s().p("AgGA5QgJgJAAgPIAAgqIgSAAIAAgaIAGAAQAPAAAAgQIAAgNIAbAAIAAAdIATAAIAAAaIgTAAIAAAlQAAAKALAAIAIgBIAAAZQgHADgJAAQgQAAgIgIg");
	this.shape_7.setTransform(-19.4,23.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2E2E2E").s().p("AgjA8QgNgKgCgPIAagHQACAIAGAEQAFAEAJAAQAXABAAgaIAAgEQgHALgSAAQgUAAgNgOQgNgNAAgUQAAgVANgNQANgPAUAAQAUAAAGAMIAAgLIAdAAIAABXQAAAXgMAOQgOAQgaAAQgUAAgOgLgAgNglQgHAFAAALQAAAJAGAGQAGAGAIAAQAKAAAGgGQAGgGAAgJQAAgLgHgFQgGgHgJAAQgHAAgGAHg");
	this.shape_8.setTransform(-29.275,26.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2E2E2E").s().p("AgOBKIAAhjIAdAAIAABjgAgMgqQgFgGAAgHQAAgHAFgGQAFgFAHAAQAHAAAFAFQAGAGAAAHQAAAHgGAGQgFAFgHAAQgHAAgFgFg");
	this.shape_9.setTransform(-37.875,22.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2E2E2E").s().p("AgtBHIAAiNIBbAAIAAAeIg7AAIAAAeIAzAAIAAAcIgzAAIAAA1g");
	this.shape_10.setTransform(-45.975,22.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgGA5QgJgJABgPIAAgqIgSAAIAAgaIAEAAQAQAAAAgQIAAgNIAbAAIAAAdIASAAIAAAaIgSAAIAAAlQgBAKALAAIAIgBIAAAZQgFADgLAAQgPAAgIgIg");
	this.shape_11.setTransform(36.7,0.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgjArQgJgIAAgNQAAgMAIgIQAIgHANgCIAWgDQAIgBAAgGQAAgFgEgDQgEgDgHAAQgGAAgFAFQgEAEgBAGIgagGQABgMAKgJQAMgMATAAQAXAAALAMQAKAKAAARIAAAvIABAQIgbAAIgBgLQgJAOgSAAQgQAAgJgKgAgDAJQgLACAAAJQAAALALAAQASAAAAgUIAAgFg");
	this.shape_12.setTransform(27.525,2.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AghAnQgQgPAAgYQAAgWAQgPQAOgPATAAQAXAAAOAOQANANAAAYIgBAJIhEAAQAAAIAHAGQAHAFAIAAQAPAAAFgNIAZAHQgEAOgLAIQgNAKgSAAQgUAAgPgOgAAUgLQAAgHgEgEQgGgGgKAAQgHAAgGAGQgFAFAAAGIAmAAIAAAAg");
	this.shape_13.setTransform(11.775,2.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgNAyIgohjIAgAAIAXA9IAUg9IAhAAIgmBjg");
	this.shape_14.setTransform(0.55,2.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgOBKIAAhjIAdAAIAABjgAgMgqQgFgGAAgHQAAgHAFgGQAFgFAHAAQAHAAAFAFQAGAGAAAHQAAAHgGAGQgFAFgHAAQgHAAgFgFg");
	this.shape_15.setTransform(-7.925,-0.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgOBIIAAiQIAdAAIAACQg");
	this.shape_16.setTransform(-13.625,0.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgkAmQgQgPAAgXQAAgWAQgPQAPgPAVAAQAXAAAPAPQAPAPAAAWQAAAXgPAPQgPAPgXAAQgVAAgPgPgAgPgSQgHAHAAALQAAAMAHAHQAHAGAIAAQAKAAAFgGQAIgHgBgMQABgLgIgHQgFgGgKAAQgIAAgHAGg");
	this.shape_17.setTransform(-27.25,2.325);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgGA5QgJgJAAgPIAAgqIgSAAIAAgaIAFAAQAQAAAAgQIAAgNIAbAAIAAAdIATAAIAAAaIgTAAIAAAlQgBAKALAAIAJgBIAAAZQgHADgKAAQgPAAgIgIg");
	this.shape_18.setTransform(-37.2,0.975);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgGA5QgJgJAAgPIAAgqIgSAAIAAgaIAGAAQAPAAAAgQIAAgNIAbAAIAAAdIATAAIAAAaIgTAAIAAAlQAAAKALAAIAIgBIAAAZQgHADgKAAQgPAAgIgIg");
	this.shape_19.setTransform(46.85,-21.325);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgeApQgJgIgBgLIAagFQAAAGAEADQAFAEAFAAQAMAAAAgIQAAgGgJgCIgLgDQgdgGgBgYQAAgNALgKQALgKAQAAQATAAALALQAJAIABALIgaAFQgCgNgMAAQgDAAgDADQgEACAAAEQAAAGAIABIAMADQAPADAIAIQAIAIAAALQAAAOgKAJQgLALgTAAQgUAAgLgMg");
	this.shape_20.setTransform(38.6,-19.975);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgfAyIAAhiIAeAAIAAANQAGgOASAAIAIABIAAAeIgJgBQgKAAgGAGQgGAHAAANIAAArg");
	this.shape_21.setTransform(30.45,-20.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgOBKIAAhjIAdAAIAABjgAgMgqQgFgGAAgHQAAgHAFgGQAFgFAHAAQAHAAAFAFQAGAGAAAHQAAAHgGAGQgFAFgHAAQgHAAgFgFg");
	this.shape_22.setTransform(23.125,-22.375);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgRBJIAAhJIgQAAIAAgZIAQAAIAAgJQAAgRAKgKQAJgLASAAQAKAAAEACIAAAZIgJgBQgNAAAAANIAAAIIAWAAIAAAZIgWAAIAABJg");
	this.shape_23.setTransform(16.625,-22.325);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AghAnQgQgPAAgYQAAgWAQgPQAOgPATAAQAXAAAOAOQANANAAAYIgBAJIhEAAQAAAIAHAGQAHAFAIAAQAPAAAFgNIAZAHQgEAOgLAIQgNAKgSAAQgUAAgPgOgAAUgLQAAgHgEgEQgGgGgKAAQgHAAgGAGQgFAFAAAGIAmAAIAAAAg");
	this.shape_24.setTransform(2.525,-19.975);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAQBIIAAg5QAAgQgQAAQgGAAgFAEQgEAEAAAHIAAA6IgfAAIAAiQIAfAAIAAA0QAJgJAPAAQATAAAKAMQAJALAAAQIAAA+g");
	this.shape_25.setTransform(-8.925,-22.25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgGA5QgJgJABgPIAAgqIgSAAIAAgaIAEAAQAQAAAAgQIAAgNIAaAAIAAAdIATAAIAAAaIgTAAIAAAlQAAAKALAAIAIgBIAAAZQgFADgLAAQgPAAgIgIg");
	this.shape_26.setTransform(-19,-21.325);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AghAnQgQgPAAgYQAAgWAQgPQAOgPATAAQAXAAAOAOQANANAAAYIgBAJIhEAAQAAAIAHAGQAHAFAIAAQAPAAAFgNIAZAHQgEAOgLAIQgNAKgSAAQgUAAgPgOgAAUgLQAAgHgEgEQgGgGgKAAQgHAAgGAGQgFAFAAAGIAmAAIAAAAg");
	this.shape_27.setTransform(-33.025,-19.975);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgyBHIAAiNIA0AAQAVAAAMALQALALAAAQQAAALgGAIQgGAIgIAEQAKABAHAJQAIAJAAANQAAARgMAMQgNALgUAAgAgTAtIATAAQAJAAAFgFQAFgEAAgIQAAgHgFgEQgFgFgJAAIgTAAgAgTgNIARAAQAHAAAFgEQAFgFAAgGQAAgPgRgBIgRAAg");
	this.shape_28.setTransform(-44.275,-22.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-64,-36.9,128,73.9), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaArIAAhUIAZAAIAAAMQAFgNAQAAIAHABIAAAaIgIgBQgJAAgFAFQgFAGAAALIAAAlg");
	this.shape.setTransform(54.375,22.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgfAhQgIgJAAgOIAAg0IAaAAIAAAvQAAAGADAEQAEAEAGAAQAGAAAEgEQADgEAAgGIAAgvIAaAAIAABEIABAPIgZAAIgBgIQgGAKgPAAQgPAAgJgKg");
	this.shape_1.setTransform(45.525,22.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOA+IAAgxQAAgOgOAAQgFAAgEADQgEAEAAAGIAAAyIgaAAIAAh7IAaAAIAAAtQAIgIANAAQAPAAAJAJQAIAKAAAOIAAA1g");
	this.shape_2.setTransform(35.475,20.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgFAwQgIgHAAgNIAAgjIgOAAIAAgXIADAAQAOAAAAgOIAAgKIAWAAIAAAYIAQAAIAAAXIgQAAIAAAeQAAAJAJAAIAHAAIAAAVQgFACgIAAQgOAAgGgHg");
	this.shape_3.setTransform(26.95,21.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgaArIAAhUIAZAAIAAAMQAFgNAQAAIAHABIAAAaIgIgBQgJAAgFAFQgFAGAAALIAAAlg");
	this.shape_4.setTransform(20.875,22.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgeAlQgHgHAAgLQgBgLAIgHQAGgFAMgCIASgDQAHgBAAgEQAAgEgEgDQgEgDgFAAQgGAAgDAEQgEAEAAAFIgXgFQABgKAIgIQALgKAQAAQATAAAKAKQAJAJgBAOIAAAoIABANIgXAAIAAgJQgIAMgQAAQgNAAgIgIgAgCAIQgKABAAAIQAAAJAKAAQAOAAABgRIAAgEg");
	this.shape_5.setTransform(12.3,22.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcAgQgOgMAAgUQAAgSAOgNQAMgNASAAQAQAAALAJQAKAIAEANIgYAHQgDgNgOAAQgHAAgFAFQgGAGAAAJQAAAKAGAGQAGAFAGAAQAOAAAEgNIAXAHQgDANgKAIQgMAJgQAAQgRAAgNgNg");
	this.shape_6.setTransform(3.1,22.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgeAlQgIgHABgLQAAgLAGgHQAIgFAKgCIATgDQAGgBAAgEQABgEgEgDQgDgDgGAAQgFAAgEAEQgEAEgBAFIgWgFQABgKAJgIQAKgKAQAAQAUAAAJAKQAIAJAAAOIAAAoIABANIgXAAIgBgJQgHAMgPAAQgOAAgIgIgAgDAIQgJABAAAIQAAAJAKAAQAOAAAAgRIAAgEg");
	this.shape_7.setTransform(-6.45,22.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAqA8IAAhPIgfBPIgVAAIgghOIAABOIgZAAIAAh3IAjAAIAgBQIAfhQIAlAAIAAB3g");
	this.shape_8.setTransform(-19.075,20.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgcAhQgNgNAAgUQAAgTANgNQAMgMAQAAQAUAAALAMQALALAAAVIAAAHIg6AAQABAHAFAEQAGAFAGAAQANAAAEgLIAWAGQgDAMgKAHQgLAIgPAAQgRAAgNgMgAARgJQAAgGgDgEQgFgEgJAAQgGAAgFAEQgEAEAAAGIAgAAIAAAAg");
	this.shape_9.setTransform(-36.125,22.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAOA+IAAgxQAAgOgOAAQgFAAgEADQgEAEAAAGIAAAyIgaAAIAAh7IAaAAIAAAtQAIgIANAAQAPAAAJAJQAIAKAAAOIAAA1g");
	this.shape_10.setTransform(-45.825,20.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgFAwQgHgHgBgNIAAgjIgPAAIAAgXIAFAAQAMAAAAgOIAAgKIAXAAIAAAYIARAAIAAAXIgRAAIAAAeQAAAJAJAAIAHAAIAAAVQgFACgJAAQgNAAgGgHg");
	this.shape_11.setTransform(-54.35,21.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAOArIAAgvQAAgPgOAAQgFAAgEAEQgEAEAAAHIAAAvIgaAAIAAhTIAZAAIAAAJQADgFAHgEQAGgCAHAAQAPAAAIAJQAIAJAAAPIAAA0g");
	this.shape_12.setTransform(50.225,1.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgMA/IAAhUIAZAAIAABUgAgKgkQgEgEAAgHQAAgGAEgEQAFgFAFAAQAGAAAFAFQAEAEAAAGQAAAHgEAEQgFAFgGAAQgFAAgFgFg");
	this.shape_13.setTransform(42.725,-0.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgeA6IATgsIgkhIIAdAAIAUAuIASguIAcAAIgzB0g");
	this.shape_14.setTransform(31.225,3.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgFAwQgHgHAAgNIAAgjIgQAAIAAgXIAFAAQANAAgBgOIAAgKIAXAAIAAAYIARAAIAAAXIgRAAIAAAeQAAAJAJAAIAHAAIAAAVQgFACgJAAQgMAAgHgHg");
	this.shape_15.setTransform(22.95,0.825);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgMA/IAAhUIAZAAIAABUgAgKgkQgEgEAAgHQAAgGAEgEQAFgFAFAAQAGAAAFAFQAEAEAAAGQAAAHgEAEQgFAFgGAAQgFAAgFgFg");
	this.shape_16.setTransform(17.525,-0.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAOArIAAgvQAAgPgOAAQgFAAgEAEQgEAEAAAHIAAAvIgaAAIAAhTIAZAAIAAAJQADgFAHgEQAGgCAHAAQAPAAAIAJQAIAJAAAPIAAA0g");
	this.shape_17.setTransform(10.125,1.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgfAhQgIgJAAgOIAAg0IAaAAIAAAvQAAAGADAEQAEAEAGAAQAGAAAEgEQADgEAAgGIAAgvIAaAAIAABEIABAPIgZAAIgBgIQgGAKgPAAQgPAAgJgKg");
	this.shape_18.setTransform(-0.025,2.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AApAsIAAgxQAAgOgOAAQgGAAgEAEQgEAFAAAFIAAAxIgZAAIAAgxQAAgOgNAAQgHAAgDAEQgEAFAAAGIAAAwIgaAAIAAhUIAZAAIAAAKQADgGAHgDQAHgEAHAAQARABAHANQAJgNARgBQANAAAJAIQAKAIAAARIAAA2g");
	this.shape_19.setTransform(-12.675,1.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AApAsIAAgxQAAgOgOAAQgGAAgEAEQgEAFAAAFIAAAxIgZAAIAAgxQAAgOgNAAQgHAAgDAEQgEAFAAAGIAAAwIgaAAIAAhUIAZAAIAAAKQADgGAHgDQAHgEAHAAQARABAHANQAJgNARgBQANAAAJAIQAKAIAAARIAAA2g");
	this.shape_20.setTransform(-27.975,1.85);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgeAgQgOgNAAgTQAAgTAOgMQAMgNASAAQATAAANANQANAMAAATQAAATgNANQgNANgTAAQgSAAgMgNgAgMgPQgGAGAAAJQAAAKAGAGQAGAFAGAAQAIAAAGgFQAFgGAAgKQAAgJgFgGQgGgFgIAAQgGAAgGAFg");
	this.shape_21.setTransform(-40.7,1.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgdAgQgNgMAAgUQAAgSANgNQANgNASAAQAQAAAMAJQAKAIACANIgWAHQgFgNgMAAQgIAAgGAFQgFAGAAAJQAAAKAGAGQAFAFAIAAQAOAAADgNIAXAHQgDANgKAIQgMAJgPAAQgTAAgNgNg");
	this.shape_22.setTransform(-50.4,1.975);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgrA7IAAh0IAZAAIAAAJQACgFAHgCQAGgDAIgBQASAAALANQALAMAAAUQAAASgMAMQgLANgSAAQgPAAgGgIIAAAmgAgNgeQgFAFAAALQAAAJAFAGQAGAFAHAAQAIAAAFgFQAGgFAAgKQAAgLgGgFQgFgGgIABQgHgBgGAGg");
	this.shape_23.setTransform(54.4,-17);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgMA/IAAhUIAZAAIAABUgAgKgkQgEgEAAgHQAAgGAEgEQAFgFAFAAQAGAAAFAFQAEAEAAAGQAAAHgEAEQgFAFgGAAQgFAAgFgFg");
	this.shape_24.setTransform(46.425,-20.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAOA9IAAgwQAAgOgOAAQgFAAgEADQgEAEAAAGIAAAxIgaAAIAAh6IAaAAIAAAsQAIgHANAAQAPAAAJAKQAIAIAAAOIAAA1g");
	this.shape_25.setTransform(39.025,-20.45);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgaAjQgHgHgBgKIAWgEQAAAFAEADQADAEAFAAQAKAAAAgIQAAgFgIgCIgJgCQgZgFAAgUQAAgLAJgJQAJgIAOAAQAQAAAJAJQAIAHAAAJIgVAEQgBgKgLAAQgDAAgDACQgCACAAADQAAAFAGACIAKACQANACAHAHQAHAHAAAJQAAAMgJAIQgJAJgQAAQgRAAgKgKg");
	this.shape_26.setTransform(29.925,-18.525);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgeAzQgLgIgCgNIAXgGQABAGAFAEQAFAEAHAAQAUAAAAgWIAAgDQgGAJgQAAQgQAAgMgMQgLgLAAgRQAAgSALgLQALgMARAAQARgBAGALIAAgJIAZAAIAABJQAAAUgLAMQgMANgWAAQgRAAgMgJgAgLggQgGAGAAAIQAAAIAFAGQAFAEAHAAQAIAAAFgEQAFgGAAgIQAAgIgFgGQgFgFgIAAQgGAAgFAFg");
	this.shape_27.setTransform(20.625,-16.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgeAlQgHgHAAgLQgBgLAIgHQAGgFAMgCIASgDQAHgBAAgEQAAgEgEgDQgEgDgFAAQgGAAgEAEQgDAEAAAFIgXgFQABgKAIgIQALgKAQAAQATAAAKAKQAJAJgBAOIAAAoIABANIgXAAIAAgJQgIAMgQAAQgNAAgIgIgAgCAIQgKABAAAIQAAAJAKAAQAOAAABgRIAAgEg");
	this.shape_28.setTransform(10.95,-18.525);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgMA9IAAh6IAZAAIAAB6g");
	this.shape_29.setTransform(4.05,-20.45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgOA+IAAg+IgOAAIAAgVIAOAAIAAgIQAAgOAIgJQAHgJAPAAQAJAAAEACIAAAVIgIgBQgLAAAAALIAAAHIATAAIAAAVIgTAAIAAA+g");
	this.shape_30.setTransform(-1.45,-20.525);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AATAqIgTg1IgRA1IgaAAIgbhTIAbAAIAPAxIAQgxIAaAAIARAxIAOgxIAaAAIgbBTg");
	this.shape_31.setTransform(-15.9,-18.525);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgcAhQgNgNAAgUQAAgTANgNQAMgMAQAAQAUAAALAMQALALAAAVIAAAHIg6AAQABAHAFAEQAGAFAGAAQANAAAEgLIAWAGQgDAMgKAHQgLAIgPAAQgRAAgNgMgAARgJQAAgGgDgEQgFgEgJAAQgGAAgFAEQgEAEAAAGIAgAAIAAAAg");
	this.shape_32.setTransform(-27.925,-18.525);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAOArIAAgvQAAgPgOAAQgFAAgEAEQgEAEAAAHIAAAvIgaAAIAAhTIAZAAIAAAJQADgFAHgEQAGgCAHAAQAPAAAIAJQAIAJAAAPIAAA0g");
	this.shape_33.setTransform(-37.625,-18.625);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAgA8IgJgYIguAAIgIAYIgdAAIAuh3IAeAAIAtB3gAAOALIgOgoIgOAoIAcAAg");
	this.shape_34.setTransform(-53.125,-20.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-66.5,-33.2,133,66.5), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgmBIIAYg2IgshZIAkAAIAYA4IAXg4IAiAAIg/CPg");
	this.shape.setTransform(38.125,29.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPBMIAAiXIAfAAIAACXg");
	this.shape_1.setTransform(29.1,24.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPBMIAAiXIAfAAIAACXg");
	this.shape_2.setTransform(23.1,24.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgmAuQgJgJAAgOQABgNAIgIQAJgHANgCIAXgEQAJgBAAgGQAAgFgEgDQgFgDgHAAQgHAAgFAEQgEAFgBAGIgcgGQABgNALgKQANgLAUAAQAYAAAMAMQALAKgBASIAAAyIACAQIgdAAIgBgMQgKAPgSAAQgRAAgLgJgAgDAKQgMACAAAJQAAALAMAAQATAAAAgVIAAgEg");
	this.shape_3.setTransform(14.2,27.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggA1IAAhoIAfAAIAAAOQAGgPAUAAIAIABIAAAgIgKgBQgKAAgHAGQgGAIAAANIAAAug");
	this.shape_4.setTransform(4.925,26.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgmAqQgKgMAAgRIAAhCIAfAAIAAA7QAAAIAFAEQAEAGAIAAQAHAAAFgFQAEgFAAgIIAAg7IAhAAIAABWIABASIgfAAIgBgKQgIANgTgBQgTABgKgMg");
	this.shape_5.setTransform(-6.05,27.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgGA8QgKgKABgPIAAgsIgTAAIAAgcIAFAAQAQAAAAgRIAAgOIAcAAIAAAfIAUAAIAAAcIgUAAIAAAmQAAALAMAAIAIgBIAAAaQgGADgLABQgQgBgIgIg");
	this.shape_6.setTransform(-16.55,25.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgmAuQgJgJAAgOQAAgNAJgIQAIgHAOgCIAXgEQAJgBgBgGQAAgFgDgDQgFgDgHAAQgHAAgFAEQgEAFgBAGIgcgGQABgNALgKQANgLAUAAQAYAAAMAMQALAKAAASIAAAyIABAQIgdAAIgBgMQgJAPgUAAQgQAAgLgJgAgDAKQgMACAAAJQAAALAMAAQATAAgBgVIAAgEg");
	this.shape_7.setTransform(-26.2,27.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARA1IAAg6QAAgTgRABQgHAAgFAEQgEAGAAAIIAAA6IggAAIAAhnIAfAAIAAAMQAEgHAJgEQAGgEAJAAQATAAAKANQAJAKAAATIAABAg");
	this.shape_8.setTransform(-37.9,26.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AggArQgJgJgBgLIAbgFQABAGAEAEQAEAEAHAAQAMAAAAgJQAAgHgKgCIgLgCQgfgHAAgZQAAgOALgKQALgKARAAQAUAAALALQAJAIABAMIgaAFQgCgNgNAAQgEAAgDACQgDADAAAEQAAAGAIACIANACQAQAEAIAIQAIAIAAAMQAAAPgKAJQgMALgUAAQgVAAgMgMg");
	this.shape_9.setTransform(27.275,2.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_10.setTransform(16.625,2.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAyA2IAAg8QAAgRgQAAQgIAAgFAFQgFAFAAAHIAAA8IgeAAIAAg8QAAgRgRAAQgIAAgFAFQgEAFAAAIIAAA7IggAAIAAhoIAeAAIAAAMQAEgGAJgFQAIgEAJAAQAWAAAIARQAMgRAUAAQARAAAKAKQAMAKAAAUIAABDg");
	this.shape_11.setTransform(1.375,2.275);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgnAoQgQgQAAgYQAAgXAQgQQAQgPAXAAQAYAAAPAPQAQAQABAXQgBAYgQAQQgPAPgYAAQgXAAgQgPgAgPgTQgIAHAAAMQAAAMAIAIQAGAGAJAAQAKAAAGgGQAHgIAAgMQAAgMgHgHQgGgGgKAAQgJAAgGAGg");
	this.shape_12.setTransform(-14.3,2.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgkAoQgQgQAAgYQAAgXAQgQQAPgPAXAAQAVAAANALQANAKADAPIgcAJQgFgQgQAAQgKAAgGAHQgIAHABALQAAAMAHAHQAHAHAJAAQARAAAEgQIAdAJQgEAPgNAKQgNALgUAAQgXAAgQgPg");
	this.shape_13.setTransform(-26.3,2.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_14.setTransform(45.425,-22.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgSBNIAAhNIgRAAIAAgbIARAAIAAgJQAAgSAKgLQAKgLATAAQAKAAAFACIAAAaIgKgBQgNAAAAAOIAAAIIAWAAIAAAbIgWAAIAABNg");
	this.shape_15.setTransform(35.775,-24.625);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgPBOIAAhoIAfAAIAABogAgMgtQgGgFABgIQgBgIAGgFQAGgGAGAAQAHAAAGAGQAFAFABAIQgBAIgFAFQgGAGgHAAQgGAAgGgGg");
	this.shape_16.setTransform(29,-24.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgPBMIAAiXIAfAAIAACXg");
	this.shape_17.setTransform(23,-24.55);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_18.setTransform(9.025,-22.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AggA1IAAhoIAfAAIAAAOQAGgPAUAAIAIABIAAAgIgKgBQgKAAgHAGQgGAIAAANIAAAug");
	this.shape_19.setTransform(-0.575,-22.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgjApQgQgQAAgZQAAgYAQgPQAPgPAUAAQAYAAAOAOQAOAOAAAZIgBAJIhHAAQAAAJAHAGQAHAFAJAAQAQAAAFgNIAaAHQgEAPgMAJQgNAJgTAAQgVAAgQgOgAAVgLQAAgIgFgEQgFgGgLAAQgIAAgGAGQgFAFgBAHIApAAIAAAAg");
	this.shape_20.setTransform(-11.125,-22.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AARBMIAAg8QAAgRgRAAQgGAAgFADQgEAFgBAHIAAA+IggAAIAAiXIAgAAIAAA2QAKgJAPAAQAUAAALAMQAJALAAASIAABBg");
	this.shape_21.setTransform(-23.15,-24.55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAgBLIgghiIgfBiIgiAAIgpiVIAjAAIAZBfIAfhfIAhAAIAfBfIAYhfIAiAAIgpCVg");
	this.shape_22.setTransform(-40.325,-24.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-66.5,-39.9,133,79.8), null);


(lib.planebyitself = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(5).p("As4G2QABgHACgJIABgeQAGg+AMgqQASg/AzgSQCNgyB+gvQBhgkE2h5QCCg0DrhiQEUhzCJg8QBGgfEihyQEoh1BAgcQgBAHgFAHQgCABgJAKQg9A9ghAiQg7A7glAgQg8AziqCOQiXB+hTBDIkTDdQj5DIh9BjQhPA/goAeQhCAzg5AlQgnAageALQgzATgigmQhqh4gvg0QhOhXgOgOQgzg3gwgoQgPgMgSgKQgXgNgUABQgXABgLAVQgHARgVAgQgUAdgEAOQgGAOgPAYQgOAUgGAOgAwQhDIiGhRQiehhhMg2QgcgUgFgUQAJgHACgCQAHgEAHAAQDPgND/gWQH+gqDsgkQDOggTGiVQAtgFABAAQAZABARASQg/AVjKAwQjvA6gaAHIwPEXQjbA6gvANQhiAbgxAOQhWAZg8AVQgoAMgUAJQgkASgKAgQgJAgAkC9QATBfAUBYQAHAYATAKQAFABADgHQABgCABgC");
	this.shape.setTransform(0.1459,-0.8005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.planebyitself, new cjs.Rectangle(-146.9,-70.9,294.1,148.4), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AljD/IAAn9ILGAAIAAH9g");
	mask.setTransform(35.55,25.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGAFIAAgBQAAgHAGAAQAHAAAAAHIAAABg");
	this.shape.setTransform(17.625,25.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AACCsIk5jyQADACAFABQALACAHgIIBjhmQAOgMARACIHTBAQgNgBgHALIi6ELIgCADQgTAYgdADIgLABQgXAAgUgPgACUhLQgFAGAAAKIAAALQAAAKAGAGQAGAFAJAAQALAAAHgFIgDgLQgHAEgGAAQgKAAAAgKIAAgBIAcAAIAAgKQAAgJgFgGQgGgGgKAAQgJAAgGAGgABiggQAHAFAMAAQAJAAAFgFQAGgFAAgHQAAgLgNgEIgHgDQgEgBAAgDQAAgDAGAAQAFAAAHADIAGgKQgIgFgKAAQgJAAgGAFQgFAEAAAHQAAAMANAEIAGACQAFACAAACQAAAEgGAAQgIAAgGgEgAA3g3QgEAEAAAHQAAARAVAAQAIAAAMgFIAAggQAAgRgTAAQgKAAgJAEIABANQAHgEAIAAQAIAAAAAGIAAACIgJAAQgJAAgFAFgAAKhLQgFAGAAAKIAAALQAAAKAGAGQAGAFAJAAQALAAAIgFIgEgLQgGAEgHAAQgJAAAAgKIAAgBIAbAAIAAgKQAAgJgFgGQgGgGgJAAQgKAAgGAGgAgUgoQAAANANAAQAEAAAFgCIgBgLIgEABQgEAAAAgFIAAg3IgNAAgAhChMQgFAFAAAIIAAARQAAAIAFAFQAGAGAKAAQAIAAANgFIAAhDIgOAAIAAAUIgJgCQgJAAgFAFgAijhLQgGAGAAAKIAAALQAAAKAHAGQAGAFAJAAQAKAAAIgFIgEgLQgGAEgHAAQgJAAAAgKIAAgBIAbAAIAAgKQAAgJgFgGQgFgGgKAAQgKAAgFAGgAjDgoQAAANANAAQAFAAAGgCIgCgLIgEABQgEAAAAgFIAAg3IgOAAgAhdg8IAAAgIAOAAIAAgkQAAgRgUAAQgJAAgNAFIAAAwIAOAAIAAgnQADgCADAAQAIAAAAAJg");
	this.shape_1.setTransform(32.5125,32.3468);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgGAFIAAgBQAAgHAGAAQAHAAAAAHIAAABg");
	this.shape_2.setTransform(48.85,25.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgGAAQAAgFAGABIAHAAIAAAJIgGABQgHgBAAgFg");
	this.shape_3.setTransform(39.675,27.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgGAFIAAgBQAAgHAGAAQAHAAAAAHIAAABg");
	this.shape_4.setTransform(35.075,25.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgGAGIAAgLQAAgJAHAAIAGACIAAAaIgFABQgIAAAAgJg");
	this.shape_5.setTransform(27.425,26.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ah4B8QgJgBgFgHQgGgIACgIIAfjLQACgMgHgJID8CRIhxgPQgSgDgMANIhjBmQgGAHgJAAIgDgBg");
	this.shape_6.setTransform(13.9839,12.4618);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ah4B8QgJgBgFgHQgGgIACgIIAfjLQACgMgHgJID8CRIhxgPQgSgDgMANIhjBmQgGAHgJAAIgDgBg");
	this.shape_7.setTransform(13.9839,12.4618);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAKhKQAGgHAIgBQAJgCAHAFQAFADADAGIAlBVQAEAKAKAFIjFA1g");
	this.shape_8.setTransform(61.225,28.9077);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAKhKQAGgHAIgBQAJgCAHAFQAFADADAGIAlBVQAEAKAKAFIjFA1g");
	this.shape_9.setTransform(61.225,28.9077);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,71.1,51), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmoGVIAAspINRAAIAAMpg");
	mask.setTransform(42.525,40.525);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AGeDtQhNgiiYgVIg2gEQiJAAiSANQimAPhiAZQgGACgCgHIAAgEQACgEADgBQBXgeBZgRQBlgVBmAAIAEgHQAHgPABgFQADgSgEgPQgEgSgLgLQgLgLgQgCQgRgCgiALQgQAGgLACQgXAFgTgFQgWgGgIgSIgBgCIgGABQgbgCgHgUQgFgNAJgJQAEgFALgHQAPgJgDgOIgEgIQgNgXAMgJQAIgFAMgBQAJgBADgBQAIgEAEgVIACgHQAEgZAMgIQANgIAWALIAHADQAQAGAegHQgBgGABgHQADgOAUgQIAJgIIgDgGIgCgIQgDgLAEgGQAEgIAJACQAIABADAGQAHAMgHANIgBADQAOAJARgCQAKgBAUgJIAUgHQARgGAKAIQALAJAAAcIAAAHQAAAUACAJQADAOAMAHQAKAFAJgHIAGgHQAKgNALgCQAKgCAGAFQAHAGAAANQgBAVAHAKIAGAHIACgBQAMgLANADQAIACACAIQADAHgFAGQgEAFgHACQgHACgFgBIgGgCQgCAHAEAFQAIAJARABQAaABAMAQQALAQABAUQAAANgFAMQgGAPgKAGQgNAIgPgHQgIgEgGgHQgIgHgEgCQgEgBgEABQgEABgFAIQgWAegogGQgKgBgXgLIgEgCQgQgIgLgDQgKgCgGADQgIADgDAHQgDAIACAIQAHATAEADQAFADgDAFQgCAFgGgCIAAAAQgMgEgFgTQgFgRADgLQADgNALgGQAMgIARAFIACAAQAJACAYALIABABQASAJALACQAPADAOgGQAGgDAJgKIAJgKQAFgFAIgCQAGgCAIADIACAAQAIAEAFAFIACACIANAJQAFACAFgBQAMgEAEgRQAEgOgEgPQgFgRgNgFQgEgDgMAAQgNAAgIgDQgRgIgDgQQgBgIACgIQgEgDgFgHQgLgPAAgPIABgIQABgJgCgCIgCgBQgGAAgHAHIgDAEQgNAOgMACQgOABgKgJQgRgPgBgfIAAgHQAAghgHgFQgEgCgGABIgUAIQgRAHgJACQgOAEgNgCQgNgCgLgIIgKAJQgUARACANQAcgHATAGQATAGAGAQQAFARgLAIQgHAFgMgCQgFAAgJgDQgLgDgMgIQgNgJgGgKQgfAIgSgFIgOgFQgKgFgEAAQgGgCgEAEQgGAFgEAVIgDAPQgGAQgIAGQgGAEgNABIgHABQgGACAAABQAAABAEAKIAFALQAIAbgcAPQgKAFgBAIQgBAFAGAFQAGAGAOABQAAgFADgEQADgGAIgBQAGgBAFAEQAHAGgCAIQgCAFgKAEIgCAAQAEAIAHAEQALAGATgCQARgBAQgFIADgBQAggLARgBQAdgBATASQARAQADAaQADAWgHAWIAAABIgFAMIAdABQBXAFBdAOIBxAEIB4AEQAGABAAAGQgBAHgGgBIh4gEIgQgBQBZATAwAVQAGACgDAGQgBAEgFAAgAjxC3Ig0ALQCbgXC9gFIhXgEQhqAAhjAVgADIhKIgEACQAIACACgDIAAgBIgCAAIgEAAgAhCiKQADAFAIAGQAGAEAFABIABABQAMAFAHABIAJgBIACgDQACgFgEgFQgIgMgVAAQgKAAgMADgAgvjaIABAGQACgFgCgEIAAgBg");
	this.shape.setTransform(42.525,23.7625);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(0,0,85.1,47.5), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmoGVIAAspINRAAIAAMpg");
	mask.setTransform(42.525,40.525);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E2E").s().p("AgiAmQgQgPABgWQgBgWAQgPQAPgQAVAAQATAAAQAOIgLAJQgKgKgOAAQgQAAgKANQgMALAAAQQAAAQAMALQAKAMAQAAQAOAAAJgIQAJgHAAgNIgdAAIAAgMIAtAAQAAAagNAOQgNANgWAAQgVAAgPgPg");
	this.shape.setTransform(28.35,59.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(23.3,54.4,10.099999999999998,10.600000000000001), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AmoGVIAAspINRAAIAAMpg");
	mask_1.setTransform(42.525,40.525);

	// Layer_3
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2E2E2E").s().p("AATA0IgagnIgNAAIAAAnIgPAAIAAhnIAnAAQAQAAAIAKQAHAKAAANQAAAMgGAIQgIAJgNABIAcAogAgUAAIAXAAQASAAgBgSQAAgTgQAAIgYAAg");
	this.shape_10.setTransform(52.6,59.7);

	var maskedShapeInstanceList = [this.shape_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(49.1,54.6,7.100000000000001,10.300000000000004), null);


(lib.Plane = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_17
	this.instance = new lib.planebyitself();
	this.instance.parent = this;
	this.instance.setTransform(-409.6,214.85,1,1,0,0,0,0.1,3.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Plane, new cjs.Rectangle(-556.6,140.8,294.1,148.3), null);


(lib.LEndlease = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.parent = this;
	this.instance.setTransform(0.05,0.15,1.4501,1.4501,0,0,0,35.6,25.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.LEndlease, new cjs.Rectangle(-51.5,-36.9,103.1,73.9), null);


(lib.FHhill = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol13();
	this.instance.parent = this;
	this.instance.setTransform(15.45,35.4);

	this.instance_1 = new lib.Symbol12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(5.25,35.4);

	this.instance_2 = new lib.Symbol11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-3.95,35.4);

	this.instance_3 = new lib.Symbol10();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-14.3,35.4);

	this.instance_4 = new lib.Symbol9();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-33.25,19.2);

	this.instance_5 = new lib.Symbol8();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-24.95,19.2);

	this.instance_6 = new lib.Symbol7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(33.2,19.2);

	this.instance_7 = new lib.Symbol6();
	this.instance_7.parent = this;
	this.instance_7.setTransform(21.9,19.2);

	this.instance_8 = new lib.Symbol5();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-1.85,19.2);

	this.instance_9 = new lib.ClipGroup_3();
	this.instance_9.parent = this;
	this.instance_9.setTransform(0,0,1,1,0,0,0,42.5,40.5);

	this.instance_10 = new lib.ClipGroup_1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(0,0,1,1,0,0,0,42.5,40.5);

	this.instance_11 = new lib.ClipGroup_2();
	this.instance_11.parent = this;
	this.instance_11.setTransform(0,0,1,1,0,0,0,42.5,40.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.FHhill, new cjs.Rectangle(-42.5,-40.5,85.1,81.1), null);


// stage content:
(lib.FHWide_skyscraper160x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{lineout:72,"lineout":170,"lineout":268});

	// trace_idn
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5).p("AFxhBQgnAIgtAJQg4AMg6AKQgUAFgjAGQgnAHgQADQguAHgWAEQg1AJgcAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgWADgtAH");
	this.shape.setTransform(-14.0866,141.9949);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1.5).p("AGHhGQg5ANhHANQg4AMg6ALQgUAEgjAGQgnAHgQADQgtAIgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_1.setTransform(-11.8616,141.5199);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1.5).p("AGchKQhIAQhhATQg5AMg6ALQgTAEgkAGQgnAGgQADQgtAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_2.setTransform(-9.8116,141.0449);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(1.5).p("AG3hRQgLADgLADQhRATh4AYQg5AMg6AKQgTAFgkAFQgnAHgPADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_3.setTransform(-7.1116,140.3949);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(1.5).p("AHQhXQgjAIgmALQhRATh4AXQg5AMg6ALQgTADgkAGQgmAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_4.setTransform(-4.5366,139.7449);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(1.5).p("AHlhdQg1APg9APQhRATh4AYQg5AMg6AJQgTAFgkAGQgmAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_5.setTransform(-2.5116,139.1949);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1.5).p("AIThrQgRAGgTAGQhLAXhgAXQhRATh4AYQg5ALg6AKQgSAFgkAGQgnAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_6.setTransform(2.1634,137.7949);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(1.5).p("AIvh1QgnAQg1AQQhLAXhgAXQhRATh4AXQg5AMg5AKQgTAFgkAGQgnAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_7.setTransform(4.9634,136.7699);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(1.5).p("AJJiCQgHAFgJADQgxAYhOAYQhLAXhgAYQhRATh4AWQg5AMg5ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_8.setTransform(7.4884,135.6295);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(1.5).p("AJUiIQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh4AWQg5AMg5ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_9.setTransform(8.5884,134.9199);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(1.5).p("AJrikQgEAMgJALQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAWQhRATh4AYQg4AMg6AKQgTAFgkAGQgnAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_10.setTransform(10.8884,132.5967);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").ss(1.5).p("AJtitQgCAUgQATQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhhAWQhQATh5AYQg3AMg6AKQgUAFgjAGQgnAHgQADQguAIgXAEQg1AJgcAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgWADgtAH");
	this.shape_11.setTransform(11.1134,131.8669);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(1.5).p("AJWjIQALAOAGANQAQAlgbAhQgOAQgTANQgPAKgXALQgxAYhOAYQhLAWhgAXQhRATh4AYQg4AMg6AKQgTAFgkAGQgnAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_12.setTransform(11.086,128.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FFFFFF").ss(1.5).p("AIwjbQAIAIAIAGQAbAbAMAZQAQAlgbAgQgOAQgTANQgPAKgXALQgxAYhOAXQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_13.setTransform(11.086,126.8213);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(1.5).p("AIYjkQAXASARAPQAbAbAMAYQAQAlgbAhQgOAQgTANQgPAKgXALQgxAYhOAXQhLAXhgAXQhRATh4AYQg4AMg6AKQgTAFgkAGQgnAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_14.setTransform(11.086,125.8715);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FFFFFF").ss(1.5).p("AHqj0QACACACABQAbASAPALQAXASARAPQAbAbAMAYQAQAlgbAhQgOAQgTANQgPAKgXALQgxAXhOAYQhLAXhgAXQhRATh4AYQg4AMg6AKQgTAFgkAGQgnAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_15.setTransform(11.086,124.2699);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1.5).p("AHGj/QARAMAXAPQAbASAPALQAXASARAPQAbAbAMAYQAQAlgbAhQgOAQgTANQgPAKgXAKQgxAYhOAYQhLAXhgAXQhRATh4AYQg4AMg6AKQgTAFgkAGQgnAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_16.setTransform(11.086,122.9949);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FFFFFF").ss(1.5).p("AHBkAQATAMAaASQAbARAPAMQAXARARAPQAbAbAMAZQAQAlgbAgQgOAQgTANQgPAKgXAKQgxAYhOAYQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_17.setTransform(11.086,122.8449);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(1.5).p("AGFkVQAQAMAUANQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAlgbAgQgOAQgTAMQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_18.setTransform(11.086,120.8199);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FFFFFF").ss(1.5).p("AFNksQAJALAPANQAEACADADQAZASAkAYQAXAQAuAeQAbASAPALQAXASARAPQAbAbAMAYQAQAlgbAhQgOAPgTANQgPAKgXALQgxAYhOAYQhLAXhgAXQhRATh4AYQg4AMg6AKQgTAFgkAGQgnAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_19.setTransform(11.086,118.4699);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(1.5).p("AFIkvQAKAOATAQQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAlgbAfQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_20.setTransform(11.086,118.1449);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FFFFFF").ss(1.5).p("AE4lGQgDAOAKATQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAlgbAfQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_21.setTransform(11.086,115.8449);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(1.5).p("AFHlUQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_22.setTransform(11.086,114.4449);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FFFFFF").ss(1.5).p("AFdlcQgNAHgJAJQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_23.setTransform(11.086,113.6449);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(1.5).p("AGTlmQgOACgKAEQgiAMgSARQgbAaATAjQAMAVAaAXQAaAVAqAaQAXAQAuAeQAbASAPALQAXASARAPQAbAbAMAYQAQAkgbAhQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAXQhRATh4AYQg4AMg6AKQgTAFgkAGQgnAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_24.setTransform(11.086,112.6699);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FFFFFF").ss(1.5).p("AG+lrQgqAHgZAJQgiALgSASQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_25.setTransform(11.086,112.2199);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(1.5).p("AHuluQgVADgUACQgvAIgbAJQgiAMgSARQgbAaATAjQAMAVAaAXQAaAVAqAaQAXAQAuAeQAbASAPALQAXASARAPQAbAbAMAYQAQAkgbAhQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAXQhRATh4AYQg4AMg6AKQgTAFgkAGQgnAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_26.setTransform(11.086,111.8949);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FFFFFF").ss(1.5).p("AIelvQgCAAgCAAQguACgnAGQgvAHgbAKQgiALgSASQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_27.setTransform(11.086,111.7449);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(1.5).p("AJNlvQgYgBgbABQguACgnAGQgvAHgbAKQgiALgSASQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_28.setTransform(11.086,111.7324);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#FFFFFF").ss(1.5).p("AJ9ltQgMgBgDAAQgqgCgzABQguACgnAGQgvAHgbAKQgiALgSASQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_29.setTransform(11.9945,111.7399);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(1.5).p("AKOlrQgGAAgGAAQgogDgFAAQgqgCgzABQguACgnAGQgvAHgbAKQgiALgSASQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh4AXQg4AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_30.setTransform(14.4634,111.7399);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#FFFFFF").ss(1.5).p("AKrlnQgLgBgHgBQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAVApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAkgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhhAYQhQATh4AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_31.setTransform(16.6062,111.7399);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(1.5).p("ALGljQgOgCgHgBQgBAAgBAAQgggBgRgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAVApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAkgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhhAYQhQATh4AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_32.setTransform(19.3298,111.7399);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FFFFFF").ss(1.5).p("ALblfQgcgCgOgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAVApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAkgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhhAYQhQATh4AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_33.setTransform(21.4401,111.7399);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFFFFF").ss(1.5).p("ALzlbIgqgDQgggDgQgCQgNgCgIgBQghgBgRgCQgSgBgbgBQgogDgFAAQgqgCgzABQguACgnAGQgvAHgbAKQgiALgSASQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAYQhRATh3AXQg5AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_34.setTransform(23.7949,111.7399);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#FFFFFF").ss(1.5).p("AMKlWIhYgIQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAVApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAkgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhhAYQhQATh4AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_35.setTransform(26.1244,111.7399);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFFFFF").ss(1.5).p("AMnlQIiSgOQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAVApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAkgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhhAYQhPATh5AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_36.setTransform(29.0254,111.7399);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#FFFFFF").ss(1.5).p("AM+lMQgXgCgLgBIiegPQgggDgQgCQgNgCgIgBQghgBgRgCQgSgBgbgBQgogDgFAAQgqgCgzABQguACgnAGQgvAHgbAKQgiALgSASQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhgAYQhQATh4AXQg5AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_37.setTransform(31.2966,111.7399);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(1.5).p("ANUlGQgCAAgEAAQgcgDgOgDQgZgCgNgBIidgPQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAVApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAkgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhhAYQhPATh5AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_38.setTransform(34.2383,111.7399);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#FFFFFF").ss(1.5).p("ANwlCIgMgCQgHAAglgCQgbgDgPgDQgZgCgMgBIiegPQgggDgQgCQgNgCgIgBQghgBgRgCQgSgBgbgBQgogDgFAAQgqgCgzABQguACgnAGQgvAHgbAKQgiALgSASQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhfAYQhRATh4AXQg5AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_39.setTransform(36.383,111.7399);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FFFFFF").ss(1.5).p("AOGk+QgFAAgDAAIgwgGQgHAAgkgCQgcgDgOgDQgZgCgNgBIidgPQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAVApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAkgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhgAYQhQATh5AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_40.setTransform(38.5298,111.7399);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FFFFFF").ss(1.5).p("AOfk6QgNgBgPgBQgYgCgNAAIgwgGQgHAAgkgCQgcgDgOgDQgZgCgNgBIidgPQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgZAaARAjQAMAVAbAWQAaAVApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAkgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhgAYQhQATh5AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_41.setTransform(41.7134,111.7399);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFFFFF").ss(1.5).p("AO0k5QghgBgmgCQgYgCgMAAIgwgGQgHAAglgCQgbgDgPgDQgZgCgMgBIiegPQgggDgQgCQgNgCgIgBQghgBgRgCQgSgBgbgBQgogDgFAAQgqgCgzABQguACgnAGQgvAHgbAKQgiALgRASQgbAaATAjQALAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhLAXhfAYQhRATh4AXQg5AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_42.setTransform(43.8633,111.7399);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FFFFFF").ss(1.5).p("APPk4QgNAAgWgBQgpAAgwgDQgYgCgNAAIgwgGQgHAAgkgCQgcgDgOgDQgZgCgNgBIidgPQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQghALgTASQgaAaASAjQAMAVAaAWQAaAVApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAkgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhJAXhhAYQhQATh5AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_43.setTransform(46.5134,111.7399);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FFFFFF").ss(1.5).p("APqk6QgUACgYAAQgNAAgggBQgpAAgwgDQgYgCgNAAIgwgGQgHAAgkgCQgcgDgOgDQgZgCgNgBIidgPQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgZAKQgiALgTASQgaAaASAjQAMAVAbAWQAZAVApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAkgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhJAXhhAYQhQATh5AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_44.setTransform(49.2134,111.7399);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#FFFFFF").ss(1.5).p("AQAk8QgJAAgMABQgRABgGAAQgUACgYAAQgNAAgggBQgoAAgxgDQgYgCgMAAIgwgGQgHAAglgCQgbgDgPgDQgZgCgMgBIiegPQgggDgQgCQgNgCgIgBQghgBgRgCQgSgBgbgBQgogDgFAAQgqgCgzABQguACgnAGQgvAHgaAKQgiALgSASQgbAaATAjQAMAVAaAWQAaAVApAbQAXAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhOAYQhKAXhgAYQhRATh4AXQg5AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_45.setTransform(51.3884,111.7399);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FFFFFF").ss(1.5).p("AQYlFQgTAEgcAEQgIABgOABQgRABgGAAQgUACgYAAQgNAAgggBQgoAAgxgDQgYgCgMAAIgwgGQgHAAglgCQgbgDgPgDQgZgCgMgBIiegPQgggDgQgCQgNgCgIgBQghgBgRgCQgSgBgbgBQgogDgFAAQgqgCgzABQguACgnAGQguAHgbAKQgiALgSASQgbAaATAjQAMAVAaAWQAaAVAqAbQAWAPAuAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhNAYQhLAXhgAYQhRATh4AXQg5AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_46.setTransform(53.7884,111.7399);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#FFFFFF").ss(1.5).p("AQylTQgRAGgUAFQgWAFgoAGQgJABgOABQgQABgGAAQgUACgYAAQgNAAgggBQgpAAgwgDQgYgCgNAAIgwgGQgHAAgkgCQgcgDgOgDQgZgCgNgBIidgPQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgvAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAVApAbQAXAPAtAfQAcARAOAMQAXARARAPQAcAbALAZQAQAkgbAgQgNAQgUANQgOAKgYALQgwAYhOAYQhKAXhhAYQhQATh5AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_47.setTransform(56.4384,111.7399);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FFFFFF").ss(1.5).p("ARIllQgkASgtALQgXAFgoAGQgIABgOABQgRABgGAAQgUACgYAAQgNAAgggBQgoAAgxgDQgYgCgMAAIgwgGQgHAAglgCQgbgDgPgDQgZgCgMgBIiegPQgggDgQgCQgNgCgIgBQghgBgRgCQgSgBgbgBQgogDgFAAQgqgCgzABQguACgmAGQgvAHgbAKQgiALgSASQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAtAfQAbARAPAMQAXARARAPQAbAbAMAZQAQAkgbAgQgOAQgTANQgPAKgXALQgxAYhNAYQhLAXhgAYQhRATh4AXQg5AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_48.setTransform(58.6634,111.7399);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FFFFFF").ss(1.5).p("ARbl1QgBABgCABQgwAfhEASQgWAFgoAFQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggBQgpgBgwgDQgYgBgNgBIgwgFQgHgBgkgCQgcgDgOgCQgZgCgNgCIidgPQgggDgQgCQgOgBgHgBQghgCgSgBQgRgBgcgCQgogCgEAAQgqgCg0AAQgsADgnAFQgwAIgaAJQgiAMgTARQgaAaASAjQAMAVAbAXQAaAVApAaQAXAQAuAeQAbASAOALQAXASARAPQAcAbALAXQAQAlgbAhQgNAQgUANQgOAKgYALQgvAYhPAYQhKAXhhAXQhQATh5AYQg4AMg6AKQgUAFgjAGQgnAHgQADQguAIgXAEQg1AJgcAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgWADgtAH");
	this.shape_49.setTransform(60.5384,111.1699);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FFFFFF").ss(1.5).p("ARqmCQgQAOgRAMQgwAfhEASQgWAFgoAFQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggBQgpgBgwgDQgYgBgNgBIgwgFQgHgBgkgCQgcgDgOgCQgZgCgNgCIidgPQgggDgQgCQgOgBgHgBQghgCgSgBQgRgBgcgCQgogCgEAAQgqgCg0AAQgsADgnAFQgwAIgaAJQgiAMgTARQgaAaASAjQAMAVAbAXQAaAVApAaQAXAQAuAeQAbASAOALQAXASARAPQAcAbALAXQAQAlgbAhQgNAQgUANQgOAKgYALQgvAYhPAYQhKAXhhAXQhQATh5AYQg4AMg6AKQgUAFgjAGQgnAHgQADQguAIgXAEQg1AJgcAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgWADgtAH");
	this.shape_50.setTransform(62.0134,110.067);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#FFFFFF").ss(1.5).p("AR6mVQgEAFgEAEQgZAhggAWQgwAfhEARQgWAFgoAGQgJABgOABQgQABgGAAQgUACgYAAQgNAAgggBQgpAAgwgDQgYgCgNAAIgwgGQgHAAgkgCQgcgDgOgDQgZgCgNgBIidgPQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgsACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAVApAbQAXAPAuAfQAcARANAMQAXARARAPQAcAaALAZQAQAlgbAgQgNAQgUANQgOAKgYALQgvAYhPAYQhKAXhhAYQhQATh5AXQg4AMg6ALQgUAEgjAGQgnAHgQADQguAJgXAEQg1AIgcAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgWACgtAI");
	this.shape_51.setTransform(63.6134,108.2356);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#FFFFFF").ss(1.5).p("ASImuQgQAhgVAZQgYAgghAWQgvAfhEASQgXAFgoAFQgIACgOABQgRAAgGAAQgUADgYAAQgNAAgggBQgogBgxgDQgYgBgMgBIgwgFQgHgBglgCQgbgDgPgCQgZgCgMgCIiegPQgggDgQgCQgNgBgIgBQghgCgRgBQgSgBgbgCQgogCgFAAQgqgCgyAAQguADgnAFQgvAIgbAJQgiAMgSARQgbAaATAjQAMAVAaAXQAaAVAqAaQAXAQAuAeQAbASAPALQAWASARAOQAbAbAMAYQAQAlgbAhQgOAQgTANQgPAKgWALQgxAYhOAYQhLAXhgAXQhRATh4AYQg5AMg6AKQgTAFgkAGQgnAHgQADQguAIgWAEQg2AJgbAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgXADgtAH");
	this.shape_52.setTransform(65.0634,105.8772);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#FFFFFF").ss(1.5).p("ASTnIIgCAFQgJAbgFAKQgTAngXAcQgYAhghAWQgvAfhEARQgXAFgoAGQgIABgOABQgRABgGAAQgUACgYAAQgNAAgggBQgoAAgxgDQgYgCgMAAIgwgGQgHAAglgCQgbgDgPgDQgZgCgMgBIiegPQgggDgQgCQgNgCgIgBQghgBgRgCQgSgBgbgBQgogDgFAAQgqgCgyABQguACgnAGQgvAHgbAKQgiALgSASQgbAaATAjQAMAVAaAWQAaAVAqAbQAXAPAuAfQAbARAPAMQAWAQARAPQAbAbAMAZQAQAlgbAgQgOAQgTANQgPAKgWALQgxAYhOAYQhLAXhgAYQhRATh4AXQg5AMg6ALQgTAEgkAGQgnAHgQADQguAJgWAEQg2AIgbAFQgwAIgXAEQgyAHgYAFQgyAJgYAEQgXACgtAI");
	this.shape_53.setTransform(66.081,103.3426);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#FFFFFF").ss(1.5).p("ASgnmQgFAGgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAdQgZAgggAWQgwAfhEASQgWAFgoAFQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggBQgpgBgwgDQgYgBgNgBIgwgFQgHgBgkgCQgcgDgOgCQgZgCgNgCIidgPQgggDgQgCQgOgBgHgBQghgCgSgBQgRgBgcgCQgogCgEAAQgqgCgzAAQgtADgnAFQgwAIgaAJQgiAMgTARQgaAaASAjQAMAVAbAXQAaAVApAaQAXAQAuAdQAcASAOALQAXASAQAPQAcAbALAYQAQAlgbAhQgNAQgUANQgNAKgYALQgwAYhPAYQhKAXhhAXQhQATh5AYQg4AMg6AKQgUAFgjAGQgnAHgQADQguAIgXAEQg1AJgcAEQgwAJgXADQgyAIgYAEQgyAJgYAEQgWADgtAH");
	this.shape_54.setTransform(67.2467,99.8699);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#FFFFFF").ss(1.5).p("AO1m+QgFAGgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAdQgZAgggAWQgwAfhEASQgWAFgoAFQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggBQgpgBgwgDQgYgBgNgBIgwgFQgHgBgkgCQgcgDgOgCQgZgCgNgCIidgPQgggDgPgCQgOgBgHgBQghgCgSgBQgRgBgcgCQgogCgEAAQgqgCg0AAQgtADgnAFQgwAIgaAJQgiAMgTARQgaAaASAjQAMAVAbAXQAaAVApAaQAXAPAuAeQAcASAOALQAXASARAPQAcAbALAYQAQAlgbAhQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhhAXQhQATh5AYQg4AMg6AKQgUAFgjAGQgIABgHAB");
	this.shape_55.setTransform(90.7333,95.8875);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#FFFFFF").ss(1.5).p("AN2mzQgFAGgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAdQgZAgggAWQgwAfhEASQgWAFgoAGQgJABgOABQgQABgGAAQgUACgYAAQgNAAgggBQgpgBgwgDQgYgBgNgBIgwgFQgHAAgkgDQgcgCgOgDQgZgCgNgCIicgPQgggDgQgCQgOgBgHgBQghgBgSgCQgRgBgcgCQgogCgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTARQgaAbASAjQAMAUAbAXQAaAVApAaQAXAPAuAeQAcASAOAMQAXARARAPQAcAbALAZQAQAkgbAhQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhhAYQhQASh5AYQggAHggAG");
	this.shape_56.setTransform(97.038,94.75);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#FFFFFF").ss(1.5).p("AMwmlQgFAHgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAcQgZAhggAWQgwAfhEARQgWAFgoAGQgJABgOABQgQABgGAAQgUACgYAAQgNAAgggBQgpAAgwgDQgYgCgNAAIgwgGQgHAAgkgCQgcgDgOgDQgZgCgNgBIicgPQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAVApAaQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAlgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhKAXhhAYQg2AMhHAP");
	this.shape_57.setTransform(104.0325,93.3423);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#FFFFFF").ss(1.5).p("ALvmXQgFAHgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAcQgZAhggAWQgwAfhEARQgWAFgoAGQgJABgOABQgQABgGAAQgUACgYAAQgNAAgggBQgpAAgwgDQgYgCgNAAIgwgGQgHAAgkgCQgcgDgOgDQgZgCgNgBIicgPQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAUApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAlgbAgQgNAQgUANQgOAKgYALQgwAYhPAYQhIAXheAX");
	this.shape_58.setTransform(110.5188,91.9142);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#FFFFFF").ss(1.5).p("ALOmIQgFAGgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAdQgZAgggAWQgwAfhEASQgWAFgoAFQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggBQgpgBgwgDQgYgBgNgBIgwgFQgHgBgkgCQgcgDgOgCQgYgCgNgCIidgPQgggDgQgCQgOgBgHgBQghgCgSgBQgRgBgcgCQgogCgEAAQgqgCg0AAQgtADgnAFQgwAIgaAJQgiAMgTARQgaAaASAjQAMAVAbAWQAaAVApAaQAXAQAuAeQAcASAOALQAXASARAPQAcAbALAYQAQAlgbAhQgNAQgUANQgOAKgYALQgwAYhPAYQgbAIgdAJ");
	this.shape_59.setTransform(113.828,90.4731);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#FFFFFF").ss(1.5).p("ALOl7QgFAHgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAcQgZAhggAWQgwAfhEARQgWAFgoAGQgJABgOABQgQABgGAAQgUACgYAAQgNAAgggBQgpAAgwgDQgYgCgNAAIgwgGQgHAAgkgCQgcgDgOgDQgYgCgNgBIidgPQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAVQAaAVApAbQAXAPAuAfQAcARAOAMQAXARARAPQAcAbALAZQAQAlgbAgQgNAQgUANQgOAKgYALQglATg4AT");
	this.shape_60.setTransform(113.828,89.1125);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#FFFFFF").ss(1.5).p("ALOlSQgFAGgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAdQgZAgggAWQgwAfhEARQgWAFgoAGQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggCQgpAAgwgDQgYgCgNAAIgwgFQgHgBgkgCQgcgDgOgCQgYgCgNgCIidgPQgggDgQgCQgOgBgHgCQghgBgSgBQgRgBgcgCQgogCgEAAQgqgDg0ABQgtADgnAFQgwAIgaAJQgiAMgTARQgaAaASAiQAMAVAbAXQAaAVApAaQAXAQAuAeQAcASAOALQAXASARAPQAcAbALAYQAQAlgbAhQgDADgDAE");
	this.shape_61.setTransform(113.828,85.1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#FFFFFF").ss(1.5).p("ALOkWQgFAGgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAdQgZAgggAWQgwAfhEARQgWAFgoAFQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggBQgpgBgwgDQgYgBgNgBIgwgFQgHgBgkgBQgcgDgOgCQgYgCgNgCIidgPQgggDgQgCQgOgBgHgCQghgBgSgBQgRgBgcgCQgogCgEAAQgqgDg0ABQgtADgnAFQgwAIgaAJQgiAMgTAQQgaAaASAjQAMAVAbAXQAaAVApAaQAXAQAuAeQAcASAOALQAXASARAPQAEAEAEAE");
	this.shape_62.setTransform(113.828,79.1);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#FFFFFF").ss(1.5).p("ALOjfQgFAHgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAcQgZAhggAVQgwAfhEARQgWAFgoAGQgJABgOABQgQABgGAAQgUACgYAAQgNAAgggBQgpAAgwgDQgYgCgNAAIgwgGQgHAAgkgCQgcgDgOgDQgYgCgNgBIidgPQgggDgQgCQgOgCgHgBQghgBgSgCQgRgBgcgBQgogDgEAAQgqgCg0ABQgtACgnAGQgwAHgaAKQgiALgTASQgaAaASAjQAMAVAbAWQAaAVApAbQAEACAEAD");
	this.shape_63.setTransform(113.828,73.5379);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#FFFFFF").ss(1.5).p("ALOi7QgFAGgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAdQgZAfggAWQgwAfhEASQgWAFgoAFQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggBQgpgBgwgDQgYgBgNgBIgwgFQgHgBgkgCQgcgDgOgCQgYgCgNgCIidgPQgggDgQgCQgOgBgHgBQghgCgSgBQgRgBgcgCQgogCgEAAQgqgCg0AAQgtADgnAFQgwAIgaAJQgiAMgTARQgaAaASAjQAIANAMAO");
	this.shape_64.setTransform(113.828,69.9831);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#FFFFFF").ss(1.5).p("AK+iSQgFAHgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAcQgZAgggAWQgwAfhEARQgWAFgoAGQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggCQgpAAgwgDQgYgCgNAAIgwgFQgHgBgkgCQgcgDgNgCQgZgCgNgCIidgPQgggDgQgCQgOgBgHgCQghgBgSgBQgRgBgcgCQgogCgEAAQgqgDg0ABQgtADgnAFQgwAIgaAJQgVAHgPAK");
	this.shape_65.setTransform(115.4333,65.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#FFFFFF").ss(1.5).p("AKEiSQgFAHgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAcQgZAgggAWQgwAfhEARQgWAFgoAGQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggCQgpAAgwgDQgYgCgNAAIgwgFQgHgBgjgCQgcgDgOgCQgZgCgNgCIidgPQgggDgQgCQgOgBgHgCQghgBgSgBQgRgBgcgCQgogCgEAAQgqgDg0ABQgqACgkAF");
	this.shape_66.setTransform(121.2333,65.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#FFFFFF").ss(1.5).p("AI/iSQgFAHgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAcQgZAgggAWQgwAfhEARQgWAFgoAGQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggCQgpAAgwgDQgYgCgMAAIgwgFQgHgBgkgCQgcgDgOgCQgZgCgNgCIidgPQgggDgQgCQgOgBgHgCQghgBgSgBQgRgBgcgCQgogCgEAAQgUgBgWgB");
	this.shape_67.setTransform(128.1032,65.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#FFFFFF").ss(1.5).p("AIIiSQgEAHgDALQgGARAAABIgNAiQgJAbgFAKQgTAngXAcQgYAgghAWQgvAfhEARQgXAFgoAGQgIACgOABQgRAAgGAAQgUADgYAAQgNAAgggCQgoAAgwgDQgYgCgMAAIgwgFQgHgBglgCQgbgDgPgCQgZgCgMgCIiegPQgggDgQgCQgNgBgIgCQghgBgRgBQgKgBgMgB");
	this.shape_68.setTransform(133.5863,65.8);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#FFFFFF").ss(1.5).p("AHViSQgFAHgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAcQgZAgggAWQgwAfhEARQgWAFgoAGQgJACgOABQgQAAgGAAQgUADgYAAQgNAAgggCQgoAAgwgDQgYgCgNAAIgwgFQgHgBgkgCQgcgDgOgCQgZgCgNgCIidgPQgSgCgNgB");
	this.shape_69.setTransform(138.7333,65.8);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#FFFFFF").ss(1.5).p("AGViSQgEAHgDALQgGARAAABIgNAiQgJAbgFAKQgTAngXAcQgYAgghAWQgvAfhEARQgXAFgoAGQgIACgOABQgRAAgGAAQgUADgXAAQgNAAgggCQgoAAgxgDQgYgCgMAAIgwgFQgHgBglgCQgbgDgPgCQgZgCgMgCIhFgG");
	this.shape_70.setTransform(145.0729,65.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#FFFFFF").ss(1.5).p("AFsiSQgFAHgCALQgGARAAABIgNAiQgKAbgFAKQgTAngWAcQgZAgggAWQgwAfhEARQgWAFgoAGQgJACgOABQgQAAgGAAQgTADgYAAQgNAAgggCQgpAAgwgDQgYgCgNAAIgwgFQgHgBgkgCQgcgDgOgCQgJgBgHgB");
	this.shape_71.setTransform(149.2333,65.8);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#FFFFFF").ss(1.5).p("AExiSQgEAHgDALQgGARAAABIgNAiQgJAbgFAKQgTAngXAcQgYAgghAWQgvAfhEARQgXAFgnAGQgIACgOABQgRAAgGAAQgUADgYAAQgNAAgggCQgoAAgxgDQgYgCgMAAIgogF");
	this.shape_72.setTransform(155.0659,65.8);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#FFFFFF").ss(1.5).p("AD/iSQgEAHgDALQgGARAAABIgNAiQgJAbgFAKQgTAngXAcQgYAgghAWQgvAfhEARQgWAFgoAGQgIACgOABQgRAAgGAAQgUADgYAAQgNAAgggCQgeAAgjgC");
	this.shape_73.setTransform(160.0881,65.8);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#FFFFFF").ss(1.5).p("ADDiSQgEAHgDALQgGARAAABIgNAiQgJAbgFAKQgTAngXAcQgYAgghAWQgvAfhDARQgXAFgoAGQgIACgOABQgRAAgGAAQgQACgSAB");
	this.shape_74.setTransform(166.0975,65.8);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#FFFFFF").ss(1.5).p("ACbiPQgEAHgDALQgGARAAABIgNAiQgJAbgFAKQgTAmgXAcQgYAhghAWQguAfhEARQgWAFgoAG");
	this.shape_75.setTransform(170.0581,65.5091);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},18).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[]},1).to({state:[{t:this.shape}]},22).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[]},1).to({state:[{t:this.shape}]},22).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).wait(1));

	// PLANE
	this.PLANE_ANIMATION = new lib.Plane();
	this.PLANE_ANIMATION.name = "PLANE_ANIMATION";
	this.PLANE_ANIMATION.parent = this;
	this.PLANE_ANIMATION.setTransform(-38.75,143.5,0.2663,0.2661,0,0,0,-409.6,211.8);

	this.timeline.addTween(cjs.Tween.get(this.PLANE_ANIMATION).to({regY:211.6,guide:{path:[-38.6,143.5,-20.6,141,-10.4,139.6,8.4,137,21.6,134.3,60.9,126.8,87.2,113.7,92.4,111.1,93.4,108.2,94.3,105.4,91.5,101.7,89,98.3,82.4,92.9,78.7,89.9,66.9,80.7,62.4,77.3,61,74.8,59.5,72.2,61.1,70.6,63.8,67.4,76.7,66.8,87.8,66.3,108,67.7,122.7,68.7,149.1,71.3,185.9,74.9,200.7,59,205.4,54.1,207.3,47.8,208.3,44.7,208.3,42.5]}},72).wait(16).to({alpha:0},7,cjs.Ease.cubicOut).to({_off:true},2).wait(1).to({_off:false,regY:211.8,x:-38.75,y:143.5,alpha:1},0).to({regY:211.6,guide:{path:[-38.6,143.5,-20.6,141,-10.4,139.6,8.4,137,21.6,134.3,60.9,126.8,87.2,113.7,92.4,111.1,93.4,108.2,94.3,105.4,91.5,101.7,89,98.3,82.4,92.9,78.7,89.9,66.9,80.7,62.4,77.3,61,74.8,59.5,72.2,61.1,70.6,63.8,67.4,76.7,66.8,87.8,66.3,108,67.7,122.7,68.7,149.1,71.3,185.9,74.9,200.7,59,205.4,54.1,207.3,47.8,208.3,44.7,208.3,42.5]}},72).wait(16).to({alpha:0},7,cjs.Ease.cubicOut).to({_off:true},2).wait(1).to({_off:false,regY:211.8,x:-38.75,y:143.5,alpha:1},0).to({regY:211.6,guide:{path:[-38.6,143.5,-20.6,141,-10.4,139.6,8.4,137,21.6,134.3,60.9,126.8,87.2,113.7,92.4,111.1,93.4,108.2,94.3,105.4,91.5,101.7,89,98.3,82.4,92.9,78.7,89.9,66.9,80.7,62.4,77.3,61,74.8,59.5,72.2,61.1,70.6,63.8,67.4,76.7,66.8,87.8,66.3,108,67.7,122.7,68.7,149.1,71.3,185.9,74.9,200.7,59,205.4,54.1,207.3,47.8,208.3,44.7,208.3,42.5]}},72).wait(9).to({alpha:0},7,cjs.Ease.cubicOut).wait(1));

	// Layer_20 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzDRbMAAAgi1MAmGAAAMAAAAi1g");
	mask.setTransform(82,87.55);

	// IMG2
	this.instance = new lib.Tween5("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(82,58);

	this.instance_1 = new lib.Tween6("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(82,247);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,y:247},90).wait(195));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:false},90).to({y:273.5,alpha:0},6).to({_off:true},1).wait(188));

	// IMG1
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-90,138);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(76,138);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_2,this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(88).to({_off:false},0).to({_off:true,x:76},88).wait(109));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(88).to({_off:false},88).to({x:160,alpha:0},9).to({_off:true},1).wait(99));

	// IMG3
	this.instance_4 = new lib.Tween7("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(179,111.85);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween8("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(39,111.85);

	var maskedShapeInstanceList = [this.instance_4,this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},178).to({state:[{t:this.instance_5}]},106).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(178).to({_off:false},0).to({_off:true,x:39},106).wait(1));

	// TEXT_3
	this.instance_6 = new lib.Symbol2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(80,345.45);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(189).to({_off:false},0).to({y:388.95,alpha:1},7,cjs.Ease.cubicOut).wait(82).to({y:438.1,alpha:0},6,cjs.Ease.cubicIn).wait(1));

	// TEXT_2
	this.instance_7 = new lib.Symbol3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(80,345.45);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(94).to({_off:false},0).to({y:388.95,alpha:1},8,cjs.Ease.cubicOut).wait(81).to({y:438.1,alpha:0},6,cjs.Ease.cubicIn).to({_off:true},1).wait(95));

	// TEXT_1
	this.instance_8 = new lib.Symbol4();
	this.instance_8.parent = this;
	this.instance_8.setTransform(80,345.45);
	this.instance_8.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({y:388.95,alpha:1},13,cjs.Ease.cubicOut).wait(73).to({y:438.1,alpha:0},7,cjs.Ease.cubicIn).to({_off:true},5).wait(187));

	// FH_hill_logo
	this.instance_9 = new lib.FHhill();
	this.instance_9.parent = this;
	this.instance_9.setTransform(80.05,277.15,1.1993,1.1984,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(285));

	// Lenmdlease_logo
	this.instance_10 = new lib.LEndlease();
	this.instance_10.parent = this;
	this.instance_10.setTransform(80,522.9,0.7478,0.7478);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(285));

	// Layer_1
	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgDAEIgCgEQAAAAABAAQAAgBAAAAQAAgBAAAAQABgBAAAAIADgCQABAAAAABQABAAAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQABAAAAAAIgCAEQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAIgDgBg");
	this.shape_76.setTransform(141.35,659.45);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgMAPQgFgGAAgJQAAgIAFgGQAFgFAHAAQAJAAAFAFQAEAGAAAIIAAACIgcAAQAAAFAEAEQADADAEAAQAIAAADgIIAGACQgCAGgEADQgFADgGAAQgHAAgGgFgAALgDQgBgEgCgDQgDgDgFAAQgDAAgDADQgDADAAAEIAUAAIAAAAg");
	this.shape_77.setTransform(137.925,658.025);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgLAYQgGgEAAgHIAHgBQAAAEADACQADADAEAAQALAAAAgMIAAgGQgDAGgIAAQgIAAgFgFQgEgEAAgIQAAgIAEgFQAFgGAIAAQAIAAADAGIAAgFIAHAAIAAAiQAAAJgDAFQgGAGgJAAQgHAAgEgEgAgHgRQgCADAAAGQAAAFACADQAEADADAAQAFAAAEgDQACgDAAgFQAAgGgCgDQgEgEgFAAQgDAAgEAEg");
	this.shape_78.setTransform(133.15,658.825);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AAJAUIAAgWQAAgKgJAAQgDAAgDADQgCADAAAFIAAAVIgHAAIAAgmIAHAAIAAAGQADgHAIAAQAGAAAEAFQAEAEgBAGIAAAYg");
	this.shape_79.setTransform(128.6,657.975);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgMARQgEgDAAgFQAAgFAEgDQADgCAFgBIAKgBQAAAAABgBQAAAAABAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQgDgCgEAAQgCAAgDACQgCACgBAEIgGgCQAAgFAEgEQAFgDAFAAQAIAAAFAEQADADAAAHIAAASIAAAGIgHAAIAAgFQgEAGgHAAQgGAAgEgDgAgCADQgGABAAAFQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAQAAABABAAQAAAAABABQAAAAABAAQABAAAAAAQALAAgBgLIAAgCg");
	this.shape_80.setTransform(124,658.025);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AAJAdIAAgXQAAgJgJAAQgDAAgCADQgDACAAAFIAAAWIgHAAIAAg5IAHAAIAAAYQAEgFAHAAQAGAAAEAEQAEAEgBAGIAAAYg");
	this.shape_81.setTransform(119.6,657.05);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgMAPQgGgGABgJQAAgIAFgGQAGgFAHAAQAHAAAFAEQAEADABAFIgHADQgBgIgJAAQgEAAgDADQgEAEABAFQgBAGAEAEQADAEAEAAQAIAAADgIIAHACQgCAFgEAEQgFADgHAAQgHAAgGgFg");
	this.shape_82.setTransform(115.05,658.025);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgNAXQgFgFAAgJQAAgIAFgFQAGgGAHAAQAJAAACAGIAAgZIAIAAIAAAzIAAAHIgHAAIAAgGIAAgBQgEAIgIAAQgIAAgFgHgAgHAAQgDADAAAGQAAAHADADQADAEAEAAQAFAAADgEQAEgEAAgGQAAgGgEgDQgDgEgFAAQgEAAgDAEg");
	this.shape_83.setTransform(108,657.1);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AAJAUIAAgWQAAgKgJAAQgDAAgDADQgCADAAAFIAAAVIgIAAIAAgmIAIAAIAAAGQAEgHAGAAQAIAAADAFQADAEABAGIAAAYg");
	this.shape_84.setTransform(103.45,657.975);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgMARQgDgDgBgFQABgFADgDQADgCAFgBIAJgBQABAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQgDgCgEAAQgCAAgDACQgCACAAAEIgIgCQABgFAFgEQAEgDAFAAQAIAAAEAEQAEADAAAHIAAASIABAGIgIAAIAAgFQgEAGgIAAQgGAAgDgDgAgCADQgGABAAAFQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAQAAABABAAQAAAAABABQAAAAABAAQABAAABAAQAJAAABgLIAAgCg");
	this.shape_85.setTransform(98.85,658.025);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgDAdIAAg5IAHAAIAAA5g");
	this.shape_86.setTransform(93.425,657.05);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgMARQgEgDABgFQgBgFAEgDQADgCAFgBIAJgBQABAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBgBgBQAAAAAAgBQAAAAgBgBQAAAAgBgBQgCgCgEAAQgCAAgDACQgCACAAAEIgHgCQAAgFAEgEQAFgDAFAAQAIAAAEAEQAEADAAAHIAAASIAAAGIgHAAIAAgFQgEAGgIAAQgFAAgEgDgAgCADQgGABAAAFQAAAAAAABQAAAAAAABQABAAAAAAQAAABABAAQAAABABAAQAAAAABABQAAAAABAAQABAAAAAAQALAAAAgLIAAgCg");
	this.shape_87.setTransform(90.1,658.025);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgDATIgPglIAIAAIAKAcIALgcIAIAAIgPAlg");
	this.shape_88.setTransform(85.875,658.025);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgNAPQgGgGAAgJQAAgIAGgGQAGgFAHAAQAJAAAFAFQAGAGAAAIQAAAJgGAGQgFAFgJAAQgHAAgGgFgAgHgJQgEAEAAAFQAAAGAEAEQADAEAEAAQAFAAAEgEQADgEAAgGQAAgFgDgEQgEgEgFAAQgEAAgDAEg");
	this.shape_89.setTransform(81.375,658.025);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgKAUIAAgmIAIAAIAAAGQACgGAIgBIADAAIAAAIIgEAAQgJAAAAALIAAAUg");
	this.shape_90.setTransform(77.725,658);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgSAbIAAg0IAHAAIAAAGQAEgHAIAAQAJAAAEAGQAFAFAAAJQAAAIgFAFQgFAGgIAAQgIAAgDgGIAAAUgAgHgQQgDAEAAAGQAAAGADADQACAEAFAAQAFAAADgEQADgDAAgGQAAgGgDgEQgDgDgFAAQgFAAgCADg");
	this.shape_91.setTransform(73.65,658.725);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgSAbIAAg0IAHAAIAAAGQAEgHAIAAQAJAAAEAGQAFAFAAAJQAAAIgFAFQgFAGgIAAQgIAAgEgGIAAAUgAgIgQQgDAEAAAGQAAAGADADQAEAEAEAAQAFAAADgEQADgDAAgGQAAgGgDgEQgDgDgFAAQgEAAgEADg");
	this.shape_92.setTransform(68.75,658.725);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AgMARQgEgDABgFQgBgFAEgDQADgCAFgBIAJgBQABAAABgBQAAAAABAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAgBgBQAAAAgBgBQgCgCgEAAQgCAAgDACQgCACAAAEIgHgCQAAgFAEgEQAFgDAFAAQAIAAAFAEQADADAAAHIAAASIAAAGIgHAAIAAgFQgEAGgIAAQgFAAgEgDgAgCADQgGABAAAFQAAAAAAABQAAAAAAABQABAAAAAAQAAABABAAQAAABABAAQAAAAABABQAAAAABAAQABAAAAAAQAKAAAAgLIAAgCg");
	this.shape_93.setTransform(63.9,658.025);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgMAYQgEgEgCgHIAIgBQABAEACACQADADAEAAQALAAAAgMIAAgGQgDAGgIAAQgHAAgFgFQgFgEgBgIQABgIAFgFQAFgGAHAAQAIAAADAGIAAgFIAHAAIAAAiQAAAJgDAFQgFAGgKAAQgHAAgFgEgAgGgRQgEADAAAGQAAAFAEADQADADADAAQAGAAACgDQAEgDAAgFQAAgGgEgDQgCgEgGAAQgDAAgDAEg");
	this.shape_94.setTransform(57.05,658.825);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AAJAUIAAgWQAAgKgJAAQgDAAgDADQgCADAAAFIAAAVIgIAAIAAgmIAIAAIAAAGQAEgHAGAAQAIAAADAFQAEAEAAAGIAAAYg");
	this.shape_95.setTransform(52.5,657.975);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgCAdIAAglIAGAAIAAAlgAgCgTQgBgBAAAAQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABgBQAAAAAAgBQAAAAABgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQABABAAAAQAAABgBAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAgBAAAAg");
	this.shape_96.setTransform(49,657.025);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AAJAUIAAgWQAAgKgJAAQgDAAgDADQgCADAAAFIAAAVIgHAAIAAgmIAHAAIAAAGQADgHAHAAQAHAAAEAFQAEAEAAAGIAAAYg");
	this.shape_97.setTransform(45.65,657.975);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AAJAUIAAgWQAAgKgJAAQgEAAgCADQgCADAAAFIAAAVIgIAAIAAgmIAIAAIAAAGQAEgHAGAAQAIAAADAFQADAEABAGIAAAYg");
	this.shape_98.setTransform(41,657.975);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgMARQgDgDgBgFQABgFADgDQADgCAFgBIAKgBQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQgCgCgFAAQgDAAgCACQgCACgBAEIgHgCQABgFAFgEQAEgDAFAAQAIAAAEAEQAEADAAAHIAAASIABAGIgIAAIAAgFQgEAGgHAAQgHAAgDgDgAgCADQgGABAAAFQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAQAAABABAAQAAAAABABQAAAAABAAQABAAABAAQAJAAABgLIAAgCg");
	this.shape_99.setTransform(36.4,658.025);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgDAdIAAg5IAHAAIAAA5g");
	this.shape_100.setTransform(33.175,657.05);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AgSAbIAAg0IAHAAIAAAGQAEgHAIAAQAIAAAFAGQAFAFAAAJQAAAIgFAFQgFAGgIAAQgIAAgEgGIAAAUgAgHgQQgEAEAAAGQAAAGAEADQACAEAFAAQAFAAADgEQADgDAAgGQAAgGgDgEQgDgDgFAAQgFAAgCADg");
	this.shape_101.setTransform(29.8,658.725);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgNAPQgGgGAAgJQAAgIAGgGQAGgFAHAAQAJAAAFAFQAGAGAAAIQAAAJgGAGQgFAFgJAAQgHAAgGgFgAgHgJQgEAEAAAFQAAAGAEAEQADAEAEAAQAFAAAEgEQADgEAAgGQAAgFgDgEQgEgEgFAAQgEAAgDAEg");
	this.shape_102.setTransform(22.575,658.025);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AAAAXQgDgEAAgFIAAgTIgIAAIAAgIIACAAQAGABAAgHIAAgFIAGAAIAAALIAJAAIAAAIIgJAAIAAASQAAAFAGABIADAAIAAAFIgGABQgFAAgBgCg");
	this.shape_103.setTransform(18.625,657.45);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AAAAWQgDgCAAgGIAAgUIgIAAIAAgHIACAAQAGAAAAgFIAAgGIAGAAIAAALIAJAAIAAAHIgJAAIAAATQAAAGAGAAIADAAIAAAGIgGABQgFAAgBgEg");
	this.shape_104.setTransform(135.975,648.3);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AgMAPQgGgGABgJQAAgIAFgGQAGgFAHAAQAHAAAFAEQAEADABAFIgGADQgCgIgJAAQgEAAgDADQgEAEAAAFQAAAGAEAEQADAEAEAAQAJAAACgIIAHACQgCAFgEAEQgFADgHAAQgHAAgGgFg");
	this.shape_105.setTransform(132.4,648.875);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("AgMAPQgFgGAAgJQAAgIAFgGQAFgFAHAAQAJAAAFAFQAEAGAAAIIAAACIgcAAQAAAFAEAEQADADAEAAQAIAAADgIIAGACQgCAGgEADQgFADgGAAQgHAAgGgFgAALgDQgBgEgCgDQgDgDgFAAQgDAAgDADQgDADAAAEIAUAAIAAAAg");
	this.shape_106.setTransform(127.925,648.875);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AgHAlIAAgGIACAAQAFAAAAgGIAAgqIAHAAIAAAqQAAAGgDADQgDADgEAAIgEAAgAAAgcQAAAAgBAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAAAAAgBQAAAAABAAQAAAAABAAQAAgBABAAQAAAAABABQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAAAgBg");
	this.shape_107.setTransform(124.275,648.7);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AgKAXIAAAFIgIAAIAAg4IAIAAIAAAYQABgCADgCQADgCAEAAQAIAAAGAGQAEAFAAAIQAAAJgFAGQgFAFgIAAQgIAAgDgGgAgIAAQgCADAAAGQAAAGACAEQADAEAFAAQAFAAADgEQADgEAAgGQAAgGgDgDQgDgEgFAAQgFAAgDAEg");
	this.shape_108.setTransform(121.2,647.95);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AgMAQQgEgFAAgHIAAgXIAIAAIAAAWQAAAFACACQACADAEAAQAEAAACgCQADgDAAgFIAAgWIAHAAIAAAfIABAHIgIAAIAAgFQgDAGgHAAQgHAAgEgEg");
	this.shape_109.setTransform(116.225,648.925);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AgNAZQgGgGgBgGIAIgDQABAFADAEQAEADAEAAQAHAAACgCQAEgDAAgEQAAgGgJgCIgHgCQgHgCgDgCQgEgEAAgGQAAgHAGgGQAFgEAGAAQAKAAAFAEQADAEACAFIgHADQgBgDgDgDQgDgEgFAAQgEAAgDADQgDADAAAEQAAAGAHACIAIACQAGABAEAEQAEAEABAGQAAAHgGAFQgFAEgJAAQgJAAgFgEg");
	this.shape_110.setTransform(111.4,647.95);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("AgDAEIgBgEQAAAAAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAIADgCQABAAAAABQABAAAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQABAAAAAAIgCAEQAAAAgBABQAAAAgBAAQAAAAgBAAQAAABgBAAIgDgCg");
	this.shape_111.setTransform(105.55,650.3);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#000000").s().p("AgMAbIAKgUIgRghIAJAAIAKAaIAMgaIAIAAIgYA1g");
	this.shape_112.setTransform(102.2,649.675);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#000000").s().p("AgDAdIAAg5IAHAAIAAA5g");
	this.shape_113.setTransform(98.925,647.9);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#000000").s().p("AAJAUIAAgWQAAgKgJAAQgEAAgCADQgCADAAAFIAAAVIgIAAIAAgmIAIAAIAAAGQAEgHAGAAQAIAAADAFQADAEAAAGIAAAYg");
	this.shape_114.setTransform(95.55,648.825);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#000000").s().p("AgNAPQgGgGAAgJQAAgIAGgGQAGgFAHAAQAJAAAFAFQAGAGAAAIQAAAJgGAGQgFAFgJAAQgHAAgGgFgAgHgJQgEAEAAAFQAAAGAEAEQADAEAEAAQAFAAAEgEQADgEAAgGQAAgFgDgEQgEgEgFAAQgEAAgDAEg");
	this.shape_115.setTransform(90.775,648.875);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#000000").s().p("AAJAUIAAgWQAAgKgJAAQgEAAgCADQgCADAAAFIAAAVIgIAAIAAgmIAIAAIAAAGQADgHAIAAQAGAAAEAFQADAEAAAGIAAAYg");
	this.shape_116.setTransform(83.95,648.825);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#000000").s().p("AgNAPQgGgGAAgJQAAgIAGgGQAGgFAHAAQAJAAAFAFQAGAGAAAIQAAAJgGAGQgFAFgJAAQgHAAgGgFgAgHgJQgEAEAAAFQAAAGAEAEQADAEAEAAQAFAAAEgEQADgEAAgGQAAgFgDgEQgEgEgFAAQgEAAgDAEg");
	this.shape_117.setTransform(79.175,648.875);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#000000").s().p("AgDAdIAAglIAHAAIAAAlgAgDgTQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBABQAAAAgBAAQAAAAgBABQAAAAgBAAQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAgBgBAAg");
	this.shape_118.setTransform(75.7,647.875);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#000000").s().p("AgKARQgDgEgBgEIAHgCQAAADACACQADACADAAQADAAACgCQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgEgFgBIgFgBQgFgBgCgCQgDgDAAgEQAAgFAEgEQAEgDAFAAQAHAAAEADQADADABAEIgHACQgBgGgHAAQAAAAAAAAQgBAAgBAAQAAAAgBABQAAAAgBABQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAAEAEABIAFABQALACAAAJQAAAEgEAEQgEADgGAAQgGAAgFgDg");
	this.shape_119.setTransform(72.675,648.875);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#000000").s().p("AgKARQgDgEgBgEIAHgCQAAADACACQADACADAAQADAAACgCQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgEgFgBIgFgBQgFgBgCgCQgDgDAAgEQAAgFAEgEQAEgDAFAAQAHAAAEADQADADABAEIgHACQgBgGgHAAQAAAAAAAAQgBAAgBAAQAAAAgBABQAAAAgBABQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAAEAEABIAFABQALACAAAJQAAAEgEAEQgEADgGAAQgGAAgFgDg");
	this.shape_120.setTransform(68.875,648.875);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#000000").s().p("AgMAPQgFgGAAgJQAAgIAFgGQAFgFAHAAQAJAAAFAFQAEAGAAAIIAAACIgcAAQAAAFAEAEQADADAEAAQAIAAADgIIAGACQgCAGgEADQgFADgGAAQgHAAgGgFgAALgDQgBgEgCgDQgDgDgFAAQgDAAgDADQgDADAAAEIAUAAIAAAAg");
	this.shape_121.setTransform(64.775,648.875);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#000000").s().p("AgKATIAAglIAIAAIAAAHQACgIAIABIADAAIAAAIIgEAAQgJAAAAAKIAAATg");
	this.shape_122.setTransform(61.225,648.85);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#000000").s().p("AgSAbIAAg0IAHAAIAAAGQAEgHAIAAQAIAAAFAGQAFAFAAAJQAAAIgFAFQgFAGgIAAQgIAAgEgGIAAAUgAgHgQQgEAEAAAGQAAAGAEADQADAEAEAAQAFAAADgEQADgDAAgGQAAgGgDgEQgDgDgFAAQgEAAgDADg");
	this.shape_123.setTransform(57.15,649.575);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#000000").s().p("AAVAUIAAgXQAAgJgIAAQgEAAgDADQgCACAAAEIAAAXIgHAAIAAgXQAAgJgIAAQgEAAgCADQgDACAAAFIAAAWIgHAAIAAgmIAHAAIAAAFQADgGAJAAQAIAAACAHQAEgHAJAAQAFAAAEAEQAEAEAAAHIAAAYg");
	this.shape_124.setTransform(51.025,648.825);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#000000").s().p("AgDAdIAAglIAHAAIAAAlgAgDgTQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBABQAAAAgBAAQAAAAgBABQAAAAgBAAQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAgBgBAAg");
	this.shape_125.setTransform(46.35,647.875);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#000000").s().p("AAAAWQgDgCAAgGIAAgUIgIAAIAAgHIACAAQAGAAAAgFIAAgGIAGAAIAAALIAJAAIAAAHIgJAAIAAATQAAAGAGAAIADAAIAAAGIgGABQgFAAgBgEg");
	this.shape_126.setTransform(41.475,648.3);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#000000").s().p("AgKARQgDgEgBgEIAHgCQAAADACACQADACADAAQADAAACgCQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgEgFgBIgFgBQgFgBgCgCQgDgDAAgEQAAgFAEgEQAEgDAFAAQAHAAAEADQADADABAEIgHACQgBgGgHAAQAAAAAAAAQgBAAgBAAQAAAAgBABQAAAAgBABQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAAEAEABIAFABQALACAAAJQAAAEgEAEQgEADgGAAQgGAAgFgDg");
	this.shape_127.setTransform(38.125,648.875);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#000000").s().p("AgCAdIAAglIAGAAIAAAlgAgCgTQgBgBAAAAQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABgBQAAgBAAAAQAAAAABgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAAAAAABQABABAAAAQAAABgBAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBABQAAAAgBAAQAAAAgBABQAAAAgBAAQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAgBAAAAg");
	this.shape_128.setTransform(35.15,647.875);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#000000").s().p("AAAAWQgDgCAAgGIAAgUIgIAAIAAgHIACAAQAGAAAAgFIAAgGIAGAAIAAALIAJAAIAAAHIgJAAIAAATQAAAGAGAAIADAAIAAAGIgGABQgFAAgBgEg");
	this.shape_129.setTransform(32.475,648.3);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#000000").s().p("AgKATIAAglIAIAAIAAAHQACgIAIABIADAAIAAAIIgEAAQgJAAAAAKIAAATg");
	this.shape_130.setTransform(29.775,648.85);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#000000").s().p("AASAcIgFgQIgZAAIgGAQIgIAAIAXg3IAIAAIAWA3gAAJAFIgJgYIgJAYIASAAg");
	this.shape_131.setTransform(25.1,647.975);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AIKBPQgFgEgBgGIAIgCQAAAEADADQADADAEAAQAMAAAAgNIAAgFQgDAGgJAAQgIAAgFgFQgFgGAAgIQAAgIAFgFQAFgFAIAAQAJAAADAGIAAgGIAHAAIAAAkQAAAIgEAFQgFAGgKAAQgHAAgFgEgAIPAlQgDAEAAAFQAAAGADADQADAEAFAAQAFAAADgEQADgDAAgGQAAgFgDgEQgDgDgFAAQgFAAgDADgAjuBPQgFgEgBgGIAIgCQAAAEADADQADADAEAAQAMAAAAgNIAAgFQgDAGgJAAQgIAAgFgFQgFgGAAgIQAAgIAFgFQAFgFAIAAQAJAAADAGIAAgGIAHAAIAAAkQAAAIgEAFQgFAGgKAAQgHAAgFgEgAjpAlQgDAEAAAFQAAAGADADQADAEAFAAQAFAAADgEQADgDAAgGQAAgFgDgEQgDgDgFAAQgFAAgDADgAhOBSIAAg2IAHAAIAAAGQAEgHAJAAQAIAAAFAGQAFAGAAAIQAAAJgFAGQgFAGgIAAQgJAAgEgGIAAAUgAhEAmQgDAEAAAFQAAAGADAEQADAEAFAAQAGAAADgEQADgEAAgGQAAgFgDgEQgDgEgGAAQgFAAgDAEgAh/BSIAAg2IAHAAIAAAGQAEgHAJAAQAIAAAFAGQAFAGAAAIQAAAJgFAGQgFAGgIAAQgJAAgEgGIAAAUgAh1AmQgDAEAAAFQAAAGADAEQADAEAFAAQAGAAADgEQADgEAAgGQAAgFgDgEQgDgEgGAAQgFAAgDAEgAoFBSIAAg2IAHAAIAAAGQAEgHAJAAQAJAAAEAGQAFAGAAAIQAAAJgFAGQgFAGgIAAQgJAAgDgGIAAAUgAn6AmQgDAEAAAFQAAAGADAEQADAEAFAAQAFAAADgEQADgEAAgGQAAgFgDgEQgDgEgFAAQgFAAgDAEgAJlBCIgCgEQAAAAAAgBQAAAAABgBQAAgBAAAAQAAAAABgBIAEgBQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQABAAAAABQAAABAAAAQAAABAAAAIgBAEQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAIgEgCgAI6A/QgGgGAAgKQAAgIAGgGQAFgGAHAAQAJAAAFAGQAFAFAAAJIAAADIgdAAQAAAFADADQADADAFAAQAJAAACgHIAHACQgCAFgEADQgFAEgHAAQgIAAgFgFgAJRAsQAAgFgDgCQgDgDgEAAQgFAAgDADQgDADAAAEIAVAAIAAAAgAGuBAQgDgDAAgFQAAgFADgDQADgCAFgBIALgCQAAAAABAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgDgFAAQgDAAgDADQgCACAAADIgHgBQAAgGAFgDQAEgEAGAAQAIAAAFAEQADAEAAAGIAAATIABAHIgIAAIAAgFQgEAGgIAAQgGAAgEgEgAG4AyQgGABAAAFQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQABAAAAABQABAAAAAAQABAAAAABQABAAABAAQALAAAAgMIAAgBgAFVA+QgGgGAAgJQAAgIAGgGQAGgGAIAAQAHAAAFAEQAEADABAFIgHADQgCgIgIAAQgFAAgDADQgEAEAAAGQAAAHAEAEQADADAFAAQAIAAADgIIAGADQgBAFgEADQgFAEgHAAQgIAAgGgGgAENA+QgFgGAAgJQAAgIAFgGQAGgGAIAAQAJAAACAHIAAgZIAIAAIAAAzIAAAHIgHAAIAAgFIAAgBQgEAHgIAAQgJAAgFgGgAETAmQgDADAAAGQAAAHADADQADAEAFAAQAFAAAEgEQADgEAAgGQAAgGgDgDQgDgEgGAAQgFAAgDAEgACzBAQgEgDAAgFQAAgFAEgDQADgCAFgBIAKgCQABAAABAAQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQgCgDgEAAQgEAAgCADQgCACgBADIgHgBQABgGAEgDQAFgEAGAAQAIAAAEAEQAEAEAAAGIAAATIAAAHIgHAAIAAgFQgEAGgJAAQgGAAgDgEgAC9AyQgGABAAAFQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABQAAAAABABQAAAAABAAQAAAAABABQABAAAAAAQALAAAAgMIAAgBgABbBAQgDgDAAgFQAAgFADgDQADgCAFgBIALgCQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgDgFAAQgDAAgDADQgCACAAADIgHgBQAAgGAFgDQAEgEAGAAQAIAAAFAEQADAEAAAGIAAATIABAHIgIAAIAAgFQgEAGgIAAQgGAAgEgEgABlAyQgGABAAAFQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQABAAAAABQABAAAAAAQABAAAAABQABAAABAAQALAAAAgMIAAgBgAADA+QgFgGAAgJQAAgIAFgGQAGgGAIAAQAJAAAFAGQAGAGAAAIQAAAJgGAGQgFAGgJAAQgIAAgGgGgAAJAlQgEAEAAAGQAAAHAEAEQADADAFAAQAFAAAEgDQADgEAAgHQAAgGgDgEQgEgDgFAAQgFAAgDADgAiqBAQgDgDAAgFQAAgFADgDQADgCAFgBIALgCQAAAAABAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgDgFAAQgDAAgDADQgCACAAADIgHgBQAAgGAFgDQAEgEAGAAQAIAAAFAEQADAEAAAGIAAATIABAHIgIAAIAAgFQgEAGgIAAQgGAAgEgEgAigAyQgGABAAAFQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQABAAAAABQABAAAAAAQABAAAAABQABAAABAAQALAAAAgMIAAgBgAm9BAQgDgDAAgFQAAgFADgDQADgCAFgBIALgCQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgDgFAAQgDAAgDADQgCACAAADIgHgBQAAgGAFgDQAEgEAGAAQAIAAAFAEQADAEAAAGIAAATIABAHIgIAAIAAgFQgEAGgIAAQgGAAgEgEgAmzAyQgGABAAAFQAAABAAAAQABABAAAAQAAABAAAAQABAAAAABQABAAAAABQABAAAAAAQABAAAAABQABAAABAAQALAAAAgMIAAgBgApIA+QgGgGAAgJQAAgIAGgGQAGgGAIAAQAJAAAFAGQAGAGAAAIQAAAJgGAGQgFAGgJAAQgIAAgGgGgApCAlQgEAEAAAGQAAAHAEAEQADADAFAAQAFAAAEgDQADgEAAgHQAAgGgDgEQgEgDgFAAQgFAAgDADgApjBAQgDgDAAgFIAAgVIgHAAIAAgHIACAAQAGAAAAgGIAAgGIAHAAIAAAMIAIAAIAAAHIgIAAIAAAUQAAAFAFAAIADAAIAAAGIgFABQgFAAgDgDgAHyBDIAAgXQAAgKgJAAQgEAAgDADQgCADAAAFIAAAWIgHAAIAAgnIAHAAIAAAGQAEgHAIAAQAHAAADAFQAEAEAAAGIAAAZgAGYBDIAAgXQAAgKgJAAQgEAAgCADQgDADAAAEIAAAXIgHAAIAAg6IAHAAIAAAYQAEgGAIAAQAHAAADAFQAEAEAAAGIAAAZgAD3BDIAAgXQAAgKgJAAQgFAAgCADQgCADAAAFIAAAWIgIAAIAAgnIAIAAIAAAGQADgHAIAAQAHAAAEAFQADAEAAAGIAAAZgACGBDIAAg6IAHAAIAAA6gAA6BDIgPgnIAIAAIALAeIALgeIAIAAIgPAngAgdBDIAAgnIAHAAIAAAHQADgHAJAAIACAAIAAAIIgDAAQgLAAAAALIAAAUgAkGBDIAAgXQAAgKgJAAQgEAAgDADQgCADAAAFIAAAWIgHAAIAAgnIAHAAIAAAGQAEgHAIAAQAHAAADAFQAEAEAAAGIAAAZgAk1BDIAAgnIAHAAIAAAngAlKBDIAAgXQAAgKgJAAQgFAAgCADQgCADAAAFIAAAWIgIAAIAAgnIAIAAIAAAGQADgHAIAAQAHAAAEAFQADAEAAAGIAAAZgAl5BDIAAgXQAAgKgJAAQgEAAgDADQgCADAAAFIAAAWIgHAAIAAgnIAHAAIAAAGQAEgHAIAAQAHAAADAFQAEAEAAAGIAAAZgAnUBDIAAg6IAIAAIAAA6gAk1ARQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAgBABAAQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAgBgAGqgIIAAgGIACAAQAFAAAAgGIAAgqIAIAAIAAArQAAAFgDADQgDAEgFAAIgEgBgADIgIIAKgUIgRgiIAJAAIAMAaIALgaIAIAAIgZA2gAj/gJIAAg1IAHAAIAAAGQAEgHAJAAQAIAAAFAGQAFAFAAAJQAAAJgFAFQgFAGgIAAQgJAAgEgGIAAAUgAj1g1QgDAEAAAGQAAAGADAEQADAEAFAAQAGAAADgEQADgEAAgGQAAgGgDgEQgDgDgGAAQgFAAgDADgAH2gcQgFgGAAgJQAAgJAGgGQAFgFAIAAQAHAAAFAEQAEADABAFIgGADQgCgIgJAAQgFAAgDADQgDAEAAAGQAAAGADAEQADAEAFAAQAJAAACgIIAHACQgCAFgEAEQgFADgHAAQgIAAgGgFgAHKgcQgGgGAAgJQAAgJAGgGQAFgFAHAAQAJAAAFAFQAFAGAAAJIAAACIgdAAQAAAFADAEQADADAFAAQAJAAACgIIAHACQgCAGgEADQgFADgHAAQgIAAgFgFgAHhgvQAAgEgDgDQgDgDgEAAQgFAAgDADQgDADAAAEIAVAAIAAAAgAGIgdIAAAFIgIAAIAAg6IAIAAIAAAZQABgDADgBQAEgCAEAAQAJAAAFAGQAEAFAAAJQAAAJgFAFQgFAGgIAAQgJAAgDgGgAGLg1QgDAEAAAGQAAAGADAEQADAEAFAAQAFAAADgEQADgEAAgGQAAgGgDgEQgDgEgFAAQgFAAgDAEgAFVgbQgEgEAAgHIAAgYIAHAAIAAAXQAAAEACADQADADAEAAQAEAAADgDQACgDAAgEIAAgXIAIAAIAAAfIAAAHIgHAAIAAgEQgEAFgIAAQgGAAgEgEgAEjgcQgFgFgBgGIAHgDQABAFADAEQAEADAGAAQAGAAADgCQADgDAAgEQAAgHgJgBIgIgCQgGgCgEgDQgEgFAAgGQAAgHAGgFQAFgFAIAAQAJAAAFAFQAEAEABAFIgHADQgBgEgCgCQgEgEgFAAQgFAAgDADQgDADAAAEQAAAGAHACIAJACQAHABAEAFQAEAEAAAGQAAAHgGAEQgFAFgJAAQgKAAgFgFgABVgcQgGgGAAgJQAAgJAGgGQAGgFAIAAQAJAAAFAFQAGAGAAAJQAAAJgGAGQgFAFgJAAQgIAAgGgFgABbg1QgEAEAAAGQAAAGAEAEQADAEAFAAQAFAAAEgEQADgEAAgGQAAgGgDgEQgEgEgFAAQgFAAgDAEgAgegcQgGgGAAgJQAAgJAGgGQAGgFAIAAQAJAAAFAFQAFAGAAAJQAAAJgFAGQgFAFgJAAQgIAAgGgFgAgYg1QgEAEAAAGQAAAGAEAEQADAEAFAAQAFAAAEgEQADgEAAgGQAAgGgDgEQgEgEgFAAQgFAAgDAEgAhcgaQgDgEgBgEIAHgCQAAADACACQADACAEAAQADAAACgCQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgEgFgBIgGgBQgFgBgCgDQgDgDAAgEQAAgFAEgEQAEgDAGAAQAHAAAEADQADADABAEIgHACQgBgGgHAAQgBAAAAAAQgBAAgBAAQAAAAgBABQAAAAgBABQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAAEAEABIAGABQALACAAAKQAAAEgEAEQgEADgGAAQgHAAgFgDgAiCgaQgDgEgBgEIAHgCQAAADACACQADACAEAAQADAAACgCQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgEgFgBIgGgBQgFgBgCgDQgDgDAAgEQAAgFAEgEQAEgDAGAAQAHAAAEADQADADABAEIgHACQgBgGgHAAQgBAAAAAAQgBAAgBAAQAAAAgBABQAAAAgBABQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAAEAEABIAGABQALACAAAKQAAAEgEAEQgEADgGAAQgHAAgFgDgAitgcQgFgGAAgJQAAgJAFgGQAFgFAIAAQAJAAAFAFQAEAGAAAJIAAACIgdAAQAAAFAEAEQADADAFAAQAIAAADgIIAGACQgCAGgEADQgFADgGAAQgIAAgGgFgAiVgvQgBgEgCgDQgDgDgFAAQgEAAgDADQgDADAAAEIAVAAIAAAAgAm1gaQgEgEAAgEIAGgCQABADACACQACACAEAAQADAAACgCQABAAAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAQAAgEgFgBIgHgBQgEgBgDgDQgCgDAAgEQAAgFAEgEQAEgDAFAAQAHAAAEADQADADABAEIgHACQgBgGgHAAQAAAAgBAAQgBAAAAAAQgBAAAAABQgBAAAAABQgBAAAAABQAAAAAAAAQgBABAAAAQAAABAAAAQAAAEAEABIAHABQAKACAAAKQAAAEgDAEQgEADgHAAQgHAAgEgDgAImgaQgDgDAAgFIAAgVIgIAAIAAgHIACAAQAGAAAAgGIAAgGIAHAAIAAAMIAJAAIAAAHIgJAAIAAAUQAAAFAGAAIADAAIAAAGIgGABQgFAAgCgDgADzgZIgCgEQAAAAAAgBQAAgBABAAQAAgBAAAAQAAAAABgBIAEgBQAAAAABAAQABAAAAAAQAAAAABABQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABQAAABAAAAIgBAEQgBABAAAAQgBAAAAAAQAAABgBAAQgBAAAAAAIgEgCgAmKgaQgDgDAAgFIAAgVIgIAAIAAgHIACAAQAGAAAAgGIAAgGIAHAAIAAAMIAJAAIAAAHIgJAAIAAAUQAAAFAGAAIADAAIAAAGIgGABQgFAAgCgDgAnkgaQgDgDAAgFIAAgVIgIAAIAAgHIACAAQAGAAAAgGIAAgGIAHAAIAAAMIAJAAIAAAHIgJAAIAAAUQAAAFAGAAIADAAIAAAGIgGABQgFAAgCgDgACxgYIAAg6IAHAAIAAA6gACcgYIAAgXQAAgKgJAAQgFAAgCAEQgCACAAAFIAAAWIgIAAIAAgmIAIAAIAAAFQADgGAIAAQAHAAAEAEQADAEAAAHIAAAYgAAogYIAAgXQAAgKgJAAQgFAAgCAEQgCACAAAFIAAAWIgIAAIAAgmIAIAAIAAAFQADgGAIAAQAHAAAEAEQADAEAAAHIAAAYgAg2gYIAAgmIAHAAIAAAmgAjOgYIAAgmIAHAAIAAAGQADgHAJAAIACAAIAAAIIgDAAQgLAAAAAMIAAATgAkVgYIAAgYQAAgJgIAAQgEAAgCADQgDADAAAEIAAAXIgHAAIAAgYQAAgJgIAAQgEAAgDADQgCADAAAEIAAAXIgIAAIAAgmIAHAAIAAAFQAEgGAIAAQAJAAADAHQAEgHAIAAQAGAAAEADQAEAEAAAHIAAAZgAlcgYIAAgmIAIAAIAAAmgAnMgYIAAgmIAIAAIAAAmgAoJgYIAAgmIAIAAIAAAGQADgHAIAAIADAAIAAAIIgEAAQgKAAAAAMIAAATgAoagYIgGgQIgaAAIgGAQIgIAAIAXg4IAJAAIAWA4gAojgvIgKgZIgKAZIAUAAgAg2hJQgBgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAAAABgBQAAAAABgBQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABABAAAAQAAABAAAAQABAAAAABQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAAAAAQgBgBAAAAgAlchJQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQABgBAAAAQAAAAAAgBQABAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQABABAAAAQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQgBAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAgBgBAAgAnMhJQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAgBABAAQAAAAAAgBQABAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQABABAAAAQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBABQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAgBgBAAgAGxhJQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQABgBAAAAQAAAAAAgBQABAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQABABAAAAQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQAAAAgBAAg");
	this.shape_132.setTransform(80.875,581.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76}]}).wait(285));

	// Register_btn
	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f().s("#000000").ss(1.5,1,1).p("AmJhpIMTAAQAsAAAeAfQAgAfAAArIAAAAQAAAsggAfQgeAggsAAIsTAAQgsAAgfggQgfgfAAgsIAAAAQAAgrAfgfQAfgfAsAAg");
	this.shape_133.setTransform(80,457.4);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#000000").s().p("AF4AqQgKgKAAgRQAAgPAJgJQAJgJANAAQAPAAAJAJQAIAJAAAPIgBAEIgxAAQAAAJAFAFQAGAGAIAAQAOAAAFgNIALAEQgDAJgHAGQgIAGgMAAQgNAAgJgJgAGAgCQgEAEgBAHIAkAAQAAgIgEgDQgGgFgIAAQgHAAgGAFgAD4ApQgKgKAAgQQAAgOAKgJQAJgKAPAAQAPAAAKAKQAJAJAAAOQAAAQgJAKQgKAKgPAAQgPAAgJgKgAEBgBQgFAGAAAKQAAALAFAHQAGAGAJAAQAJAAAGgGQAGgHAAgLQAAgKgGgGQgGgGgJAAQgJAAgGAGgAgcApQgKgKAAgQQAAgOAKgJQAJgKAPAAQANAAAKAKQAKAJAAAOQAAAQgKAKQgKAKgNAAQgPAAgJgKgAgTgBQgGAGAAAKQAAALAGAHQAGAGAJAAQAIAAAFgGQAGgHAAgLQAAgKgGgGQgFgGgIAAQgJAAgGAGgAj5ApQgKgKAAgQQAAgPAKgJQAJgJAOAAQAMAAAJAGQAGAGACAIIgLAFQgEgNgOAAQgIAAgGAFQgGAGAAAKQAAALAGAHQAGAGAIAAQAPAAAEgOIALAFQgCAIgHAGQgJAHgMAAQgOAAgJgKgAmdAmQgPgOAAgYQAAgWAPgOQAOgOATAAQARAAALAJQALAIAEAOIgMAFQgGgXgZAAQgOAAgKAKQgKAKAAARQAAASAKALQAKAJAOAAQAMAAAJgGQAHgGADgLIAMAEQgEAOgLAJQgLAJgRAAQgUAAgNgNgAFBAxIAAhBIANAAIAAALQAFgMAOAAIAEAAIAAAOIgFAAQgSAAAAASIAAAigADUAxIAAgqQAAgOgOAAQgHAAgEAFQgEAEAAAHIAAAoIgNAAIAAgqQAAgOgOAAQgHAAgEAFQgFADAAAIIAAAoIgMAAIAAhBIAMAAIAAAIQAGgKAOAAQAOAAAGAMQAHgMAPAAQAJAAAGAGQAIAHAAALIAAArgAAtAxIAAhBIAMAAIAAALQAGgMAOAAIAEAAIAAAOIgFAAQgTAAAAASIAAAigAhKAxIAAg2IgMAAIAAgLIAMAAIAAgLQAAgLAGgGQAGgGAKAAQAGAAABACIAAALIgFgBQgLAAAAALIAAALIAQAAIAAALIgQAAIAAA2gAiLAxIgVgeIgJAKIAAAUIgNAAIAAhjIANAAIAAA+IAcgcIASAAIgcAbIAdAmgAkfAxIAAhBIANAAIAABBgAlBAxIAAhjIANAAIAABjgAkggiQgCgDAAgEQAAgEACgDQADgCAEAAQAEAAADACQACADAAAEQAAAEgCADQgDACgEAAQgEAAgDgCg");
	this.shape_134.setTransform(79.125,457.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_134},{t:this.shape_133}]}).wait(285));

	// BKG
	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#F26522").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_135.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_135).wait(285));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.2,276.1,249,388);
// library properties:
lib.properties = {
	id: '56DC97A13D194E2C906C95BBEC24E126',
	width: 160,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Wide_skyscraper160x600/gh-pages/images/IMG01jpgcopy.jpg", id:"IMG01jpgcopy"},
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Wide_skyscraper160x600/gh-pages/images/IMG02jpgcopy.jpg", id:"IMG02jpgcopy"},
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Wide_skyscraper160x600/gh-pages/images/IMG03.jpg", id:"IMG03"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['56DC97A13D194E2C906C95BBEC24E126'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;